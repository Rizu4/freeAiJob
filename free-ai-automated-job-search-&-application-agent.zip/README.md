# Free AI Automated Job Search & Application Agent

An autonomous, personal AI Job Search and Application Web Application and Background Agent designed to find suitable international jobs worldwide using your CV and automate the application process as much as legally and technically permitted.

Built with **₹0 budget** in mind: uses completely free and open-source technologies, public job APIs, local file persistence, and GitHub Actions scheduled automation.

---

## 🌟 Key Features

1. **Candidate Profile & Truthful CV Parser**:
   - Supports PDF, DOCX, and text paste.
   - Extracts contact info, education, employment dates, skills, software tools, and languages.
   - **Zero Hallucination Guarantee**: Never invents degrees, past employers, or fake work authorizations.
2. **International Relocation & Visa Sponsorship Engine**:
   - Preconfigured for UAE, Saudi Arabia, Qatar, Poland, Germany, Netherlands, Ireland, Australia, New Zealand, Canada, and the United Kingdom.
   - Prioritizes vocational roles: *Document Controller, Data Entry Operator, Computer Operator, Office Assistant, Warehouse Assistant, Storekeeper, Inventory Assistant, Junior IT Support*.
   - Evaluates genuine visa sponsorship evidence and work permit support.
3. **Transparent 0–100 Match Scoring**:
   - Mathematical breakdown of Title Match (25%), Skills (25%), Experience (15%), Location (15%), Visa Sponsorship (15%), and Language (5%).
   - Full point breakdown and explanations for every score.
4. **Dual Application Pipeline**:
   - **Fully Automatic Mode**: Dispatches applications through supported, permitted intake channels with verifiable reference codes.
   - **Manual Action Queue**: Automatically detects applications requiring CAPTCHA, Workday/Greenhouse account logins, or 2FA. Pre-fills candidate packets with 1-click clipboard copying.
5. **Tailored Truthful Cover Letter Generator**:
   - Synthesizes your verified CV with real job descriptions.
   - Generates professional letters using Google Gemini 3.8 Flash or built-in deterministic templates. Downloadable in TXT format.
6. **24/7 Free Automation via GitHub Actions**:
   - Ready-to-use cron workflow runs twice daily for ₹0 on your GitHub repository.
7. **Complete Data Sovereignty & Privacy**:
   - 100% local database (`data/db.json` and SQLite). Zero tracking, zero passwords stored, 1-click full JSON export and permanent wipe.

---

## 🛠️ Technology Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS, Lucide Icons.
- **Backend**: Node.js + Express (with full Vite dev server integration) & Python standalone alternative (FastAPI + SQLite).
- **AI Engine**: `@google/genai` (Gemini 3.8 Flash) with rule-based deterministic NLP fallback.
- **Automation Runner**: GitHub Actions Scheduled Workflow (`.github/workflows/job_agent_cron.yml`).

---

## 🚀 Quick Start Guide

### Running Locally (Node.js)

```bash
# 1. Clone repository
git clone https://github.com/<YOUR_USERNAME>/free-ai-job.git
cd free-ai-job

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Running with Python (Standalone Agent Runner)

```bash
# 1. Install Python dependencies
pip install -r backend/requirements.txt

# 2. Initialize database
python backend/database.py

# 3. Run job search & application agent cycle
python backend/agent_runner.py
```

---

## 🤖 GitHub Actions Setup (`free-ai-job`)

To have the agent search for jobs and process applications automatically twice daily:

1. Push this project to your GitHub repository named `free-ai-job`.
2. Go to **Settings → Secrets and variables → Actions**.
3. Add a new secret:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: Your free API key from Google AI Studio.
4. Enable Actions in the **Actions** tab.
5. The scheduled job runs automatically at `00:00` and `12:00` UTC every day!

---

## 🔒 Truthful Application Policy

- **No CAPTCHA Bypassing**: The agent respects website security. Applications that require logins or anti-bot verification are placed into the **Manual Action Required** queue with direct links and pre-filled data.
- **No Fabricated Credentials**: All applications are prepared strictly from verified facts extracted from your uploaded CV.
