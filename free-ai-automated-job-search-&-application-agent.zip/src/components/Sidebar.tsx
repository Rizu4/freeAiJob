import React from 'react';
import {
  LayoutDashboard,
  Upload,
  UserCheck,
  Sliders,
  Globe2,
  CheckCircle2,
  Cpu,
  Clock,
  Send,
  AlertTriangle,
  AlertOctagon,
  Bookmark,
  FileText,
  History,
  CalendarCheck,
  Settings,
  ShieldCheck,
} from 'lucide-react';
import type { DashboardStats } from '../types.ts';

export type NavigationTab =
  | 'overview'
  | 'upload-cv'
  | 'profile'
  | 'preferences'
  | 'search'
  | 'matched'
  | 'auto-applications'
  | 'in-progress'
  | 'submitted'
  | 'failed'
  | 'manual-action'
  | 'saved'
  | 'cover-letters'
  | 'history'
  | 'schedule'
  | 'settings'
  | 'privacy';

interface NavItem {
  id: NavigationTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  count?: number;
  highlight?: boolean;
  badge?: string;
  badgeColor?: string;
}

interface SidebarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  stats?: DashboardStats | null;
  savedJobsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  stats,
  savedJobsCount,
}) => {
  const navGroups: { group: string; items: NavItem[] }[] = [
    {
      group: 'Overview & Runner',
      items: [
        { id: 'overview' as NavigationTab, label: 'Overview', icon: LayoutDashboard },
        {
          id: 'schedule' as NavigationTab,
          label: 'Automation Schedule',
          icon: CalendarCheck,
          badge: stats?.lastSuccessfulRun ? 'Active' : undefined,
          badgeColor: 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40',
        },
        { id: 'history' as NavigationTab, label: 'Search History', icon: History },
      ],
    },
    {
      group: 'Profile & Matching Rules',
      items: [
        { id: 'upload-cv' as NavigationTab, label: 'Upload CV', icon: Upload },
        { id: 'profile' as NavigationTab, label: 'Candidate Profile', icon: UserCheck },
        { id: 'preferences' as NavigationTab, label: 'Job Preferences', icon: Sliders },
      ],
    },
    {
      group: 'Job Discovery',
      items: [
        {
          id: 'search' as NavigationTab,
          label: 'International Search',
          icon: Globe2,
          count: stats?.jobsDiscovered,
        },
        {
          id: 'matched' as NavigationTab,
          label: 'Matched Jobs',
          icon: CheckCircle2,
          count: stats?.jobsMatchingProfile,
        },
        {
          id: 'saved' as NavigationTab,
          label: 'Saved Jobs',
          icon: Bookmark,
          count: savedJobsCount > 0 ? savedJobsCount : undefined,
        },
      ],
    },
    {
      group: 'Application Pipeline',
      items: [
        {
          id: 'manual-action' as NavigationTab,
          label: 'Manual Action Required',
          icon: AlertTriangle,
          count: stats?.manualActionRequired,
          highlight: stats?.manualActionRequired ? true : false,
        },
        {
          id: 'auto-applications' as NavigationTab,
          label: 'Automatic Applications',
          icon: Cpu,
        },
        {
          id: 'in-progress' as NavigationTab,
          label: 'Applications in Progress',
          icon: Clock,
          count: stats?.applicationsPrepared,
        },
        {
          id: 'submitted' as NavigationTab,
          label: 'Submitted Applications',
          icon: Send,
          count: stats?.applicationsSubmitted,
        },
        {
          id: 'failed' as NavigationTab,
          label: 'Failed Applications',
          icon: AlertOctagon,
          count: stats?.failedSubmissions ? stats.failedSubmissions : undefined,
        },
      ],
    },
    {
      group: 'Documents & Setup',
      items: [
        { id: 'cover-letters' as NavigationTab, label: 'Cover Letters', icon: FileText },
        { id: 'settings' as NavigationTab, label: 'Settings', icon: Settings },
        { id: 'privacy' as NavigationTab, label: 'Privacy & Data', icon: ShieldCheck },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-neutral-950 border-r border-neutral-800 flex flex-col shrink-0 select-none h-screen sticky top-0 overflow-hidden">
      {/* Brand Header */}
      <div className="h-14 px-4 flex items-center gap-3 border-b border-neutral-800">
        <div className="w-7 h-7 rounded-md bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-sm">
          JA
        </div>
        <div className="flex flex-col">
          <span className="font-semibold text-sm tracking-tight text-neutral-100">JobAgent AI</span>
          <span className="text-[11px] text-neutral-400 font-mono">Personal Edition · ₹0 Free</span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {navGroups.map((group) => (
          <div key={group.group}>
            <div className="px-2 pb-1 text-[11px] font-semibold tracking-wider text-neutral-400 uppercase">
              {group.group}
            </div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-neutral-800 text-neutral-100 shadow-sm'
                        : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive
                            ? 'text-emerald-400'
                            : item.highlight
                            ? 'text-amber-400'
                            : 'text-neutral-500'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.count !== undefined && item.count > 0 && (
                      <span
                        className={`tabular-nums text-[10px] px-1.5 py-0.5 rounded font-mono ${
                          item.highlight
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : isActive
                            ? 'bg-neutral-700 text-neutral-200'
                            : 'bg-neutral-900 text-neutral-400'
                        }`}
                      >
                        {item.count}
                      </span>
                    )}

                    {item.badge && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-medium ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer info */}
      <div className="p-3 border-t border-neutral-800/80 bg-neutral-950/60 text-[11px] text-neutral-400">
        <div className="flex items-center justify-between">
          <span>Cost: <strong className="text-neutral-300">₹0 Forever</strong></span>
          <span className="font-mono text-neutral-400">v1.2.0</span>
        </div>
      </div>
    </aside>
  );
};
