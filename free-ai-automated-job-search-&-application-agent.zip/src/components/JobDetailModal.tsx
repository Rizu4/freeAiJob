import React from 'react';
import {
  X,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  FileCheck,
  Building2,
  MapPin,
  Clock,
  Sparkles,
  AlertTriangle,
} from 'lucide-react';
import type { JobListing, CandidateProfile } from '../types.ts';

interface JobDetailModalProps {
  job: JobListing | null;
  profile: CandidateProfile;
  isOpen: boolean;
  onClose: () => void;
  onPrepareApplication: (jobId: string) => void;
  onGenerateCoverLetter: (job: JobListing) => void;
  isPreparing?: boolean;
}

export const JobDetailModal: React.FC<JobDetailModalProps> = ({
  job,
  profile,
  isOpen,
  onClose,
  onPrepareApplication,
  onGenerateCoverLetter,
  isPreparing,
}) => {
  if (!isOpen || !job) return null;

  const { matchBreakdown, visaSponsorshipEvidence } = job;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-neutral-950 border border-neutral-800 rounded-lg shadow-xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <span className="text-neutral-300 font-medium">{job.company}</span>
              <span aria-hidden="true">·</span>
              <span>{job.location} ({job.country})</span>
              <span aria-hidden="true">·</span>
              <span>{job.source}</span>
            </div>
            <h2 className="text-base font-bold text-neutral-100 mt-1">{job.title}</h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-100 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          {/* Match Score Strip */}
          <div className="p-4 rounded-lg bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-4">
            <div>
              <div className="text-neutral-400">Candidate Match Score</div>
              <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400 mt-0.5">
                {job.matchScore} / 100
              </div>
            </div>

            <div className="text-right">
              <span
                className={`inline-block px-2.5 py-1 rounded text-xs font-medium ${
                  job.applicationMethod === 'auto_permitted'
                    ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40'
                    : 'text-amber-400 bg-amber-950/60 border border-amber-800/40'
                }`}
              >
                {job.applicationMethod === 'auto_permitted'
                  ? 'Automated Submission Supported'
                  : 'Manual Action Required'}
              </span>
              <div className="text-[11px] text-neutral-400 mt-1">
                {job.salaryText || 'Market standard rate'}
              </div>
            </div>
          </div>

          {/* Visa Sponsorship Evidence Spotlight */}
          <div className="p-3.5 rounded-lg bg-neutral-900/60 border border-neutral-800 space-y-1.5">
            <div className="flex items-center gap-2 font-medium text-neutral-200">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Visa Sponsorship & Work Permit Assessment</span>
            </div>
            <p className="text-neutral-300 leading-relaxed">
              &ldquo;{visaSponsorshipEvidence?.evidenceSnippet || 'Sponsorship details pending employer questionnaire.'}&rdquo;
            </p>
            <div className="text-[11px] text-neutral-400">
              Evidence Type:{' '}
              {visaSponsorshipEvidence?.sourceType === 'explicit_listing'
                ? 'Explicitly confirmed in employer vacancy notice'
                : 'National work permit category eligibility'}
            </div>
          </div>

          {/* Transparent Score Breakdown */}
          <div className="space-y-2.5">
            <div className="font-semibold text-neutral-200 text-xs">Transparent Scoring Formula</div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-400 text-[11px]">Title Match</div>
                <div className="font-mono text-neutral-200 font-bold mt-0.5">
                  {matchBreakdown?.titleScore ?? 0} / 25
                </div>
              </div>
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-400 text-[11px]">Skills & Tools</div>
                <div className="font-mono text-neutral-200 font-bold mt-0.5">
                  {matchBreakdown?.skillsScore ?? 0} / 25
                </div>
              </div>
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-400 text-[11px]">Location / Country</div>
                <div className="font-mono text-neutral-200 font-bold mt-0.5">
                  {matchBreakdown?.countryScore ?? 0} / 15
                </div>
              </div>
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-400 text-[11px]">Visa Sponsorship</div>
                <div className="font-mono text-neutral-200 font-bold mt-0.5">
                  {matchBreakdown?.sponsorshipScore ?? 0} / 15
                </div>
              </div>
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-400 text-[11px]">Experience Fit</div>
                <div className="font-mono text-neutral-200 font-bold mt-0.5">
                  {matchBreakdown?.experienceScore ?? 0} / 15
                </div>
              </div>
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-400 text-[11px]">Language Standard</div>
                <div className="font-mono text-neutral-200 font-bold mt-0.5">
                  {matchBreakdown?.languageScore ?? 0} / 5
                </div>
              </div>
            </div>

            {/* Explanation Bullets */}
            {matchBreakdown?.explanation && matchBreakdown.explanation.length > 0 && (
              <ul className="space-y-1 text-neutral-400 text-[11px] list-disc list-inside pt-1">
                {matchBreakdown.explanation.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            )}
          </div>

          {/* Job Description */}
          <div className="space-y-2">
            <div className="font-semibold text-neutral-200 text-xs">Job Description & Duties</div>
            <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-300 whitespace-pre-line leading-relaxed max-h-56 overflow-y-auto">
              {job.description}
            </div>
          </div>

          {/* Manual Action Warning if required */}
          {job.applicationMethod === 'manual_required' && (
            <div className="p-3 rounded bg-amber-950/40 border border-amber-800/40 text-amber-300 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                <span className="font-medium">Manual Action Notice:</span> {job.manualActionReason}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between gap-3">
          <a
            href={job.originalUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs text-neutral-400 hover:text-neutral-200 transition-colors"
          >
            <span>Original Listing</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onGenerateCoverLetter(job)}
              className="px-3 py-1.5 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 rounded transition-colors"
            >
              Tailor Cover Letter
            </button>
            <button
              onClick={() => onPrepareApplication(job.id)}
              disabled={isPreparing}
              className="px-4 py-1.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
            >
              {isPreparing ? 'Preparing...' : 'Prepare Application Package'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
