import React, { useState } from 'react';
import {
  Sliders,
  Globe2,
  Briefcase,
  DollarSign,
  ShieldAlert,
  CheckCircle2,
  Save,
  Plus,
  Trash2,
} from 'lucide-react';
import type { JobPreferences } from '../../types.ts';
import { updatePreferences } from '../../utils/api.ts';

interface JobPreferencesViewProps {
  preferences: JobPreferences;
  onPreferencesUpdated: (updated: JobPreferences) => void;
}

const standardCountries = [
  'United Arab Emirates',
  'Saudi Arabia',
  'Qatar',
  'Poland',
  'Germany',
  'Netherlands',
  'Ireland',
  'Australia',
  'New Zealand',
  'Canada',
  'United Kingdom',
];

const standardRoles = [
  'Document Controller',
  'Data Entry Operator',
  'Computer Operator',
  'Office Assistant',
  'Warehouse Assistant',
  'Storekeeper',
  'Inventory Assistant',
  'Administrative Assistant',
  'Junior IT Support',
];

const availableSources = [
  'Arbeitnow Public API',
  'Jobicy Global Jobs',
  'Remotive Free API',
  'Gulf & Middle East Public Feeds',
  'European Visa-Sponsored Portal',
];

export const JobPreferencesView: React.FC<JobPreferencesViewProps> = ({
  preferences,
  onPreferencesUpdated,
}) => {
  const [form, setForm] = useState<JobPreferences>(preferences);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [newCountry, setNewCountry] = useState('');
  const [newRole, setNewRole] = useState('');
  const [newExcludedEmp, setNewExcludedEmp] = useState('');

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      const res = await updatePreferences(form);
      onPreferencesUpdated(res.preferences);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      console.error('Failed to update preferences:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const toggleCountry = (country: string) => {
    if (form.targetCountries.includes(country)) {
      setForm({ ...form, targetCountries: form.targetCountries.filter((c) => c !== country) });
    } else {
      setForm({ ...form, targetCountries: [...form.targetCountries, country] });
    }
  };

  const toggleRole = (role: string) => {
    if (form.targetRoles.includes(role)) {
      setForm({ ...form, targetRoles: form.targetRoles.filter((r) => r !== role) });
    } else {
      setForm({ ...form, targetRoles: [...form.targetRoles, role] });
    }
  };

  const toggleSource = (source: string) => {
    if (form.enabledSources.includes(source)) {
      setForm({ ...form, enabledSources: form.enabledSources.filter((s) => s !== source) });
    } else {
      setForm({ ...form, enabledSources: [...form.enabledSources, source] });
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-neutral-100">Job Preferences & Targeting Rules</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Configure destination countries, vocational categories, visa sponsorship thresholds, and employer exclusions.
          </p>
        </div>

        <button
          onClick={handleSave}
          disabled={isSaving}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50 shrink-0 cursor-pointer"
        >
          <Save className="w-3.5 h-3.5" />
          <span>{isSaving ? 'Saving...' : 'Save Job Rules'}</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 rounded bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Preferences saved. Job matching filter and threshold updated automatically.</span>
        </div>
      )}

      {/* Target Countries Grid */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
              <Globe2 className="w-4 h-4 text-emerald-400" />
              <span>Target Destination Countries</span>
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Select target international relocation markets offering visa sponsorship / work permits.
            </p>
          </div>
          <span className="text-xs font-mono text-neutral-400">
            {form.targetCountries.length} Selected
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs">
          {standardCountries.map((country) => {
            const isSelected = form.targetCountries.includes(country);
            return (
              <button
                type="button"
                key={country}
                onClick={() => toggleCountry(country)}
                className={`p-2.5 rounded text-left border transition-colors flex items-center justify-between ${
                  isSelected
                    ? 'bg-neutral-900 border-emerald-500/40 text-neutral-100'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <span>{country}</span>
                {isSelected && <span className="text-emerald-400 text-xs">✓</span>}
              </button>
            );
          })}
        </div>

        {/* Custom countries */}
        <div className="pt-2">
          <div className="flex gap-2 max-w-sm">
            <input
              type="text"
              value={newCountry}
              onChange={(e) => setNewCountry(e.target.value)}
              placeholder="Add other country..."
              className="flex-1 p-2 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-100"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newCountry.trim()) {
                  e.preventDefault();
                  if (!form.targetCountries.includes(newCountry.trim())) {
                    setForm({ ...form, targetCountries: [...form.targetCountries, newCountry.trim()] });
                  }
                  setNewCountry('');
                }
              }}
            />
            <button
              type="button"
              onClick={() => {
                if (newCountry.trim() && !form.targetCountries.includes(newCountry.trim())) {
                  setForm({ ...form, targetCountries: [...form.targetCountries, newCountry.trim()] });
                  setNewCountry('');
                }
              }}
              className="px-3 py-1.5 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded"
            >
              Add
            </button>
          </div>
        </div>
      </div>

      {/* Target Job Roles */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-blue-400" />
              <span>Target Job Categories & Vocational Roles</span>
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Prioritize entry-level and vocational roles suitable for candidates applying from India.
            </p>
          </div>
          <span className="text-xs font-mono text-neutral-400">
            {form.targetRoles.length} Selected
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs">
          {standardRoles.map((role) => {
            const isSelected = form.targetRoles.includes(role);
            return (
              <button
                type="button"
                key={role}
                onClick={() => toggleRole(role)}
                className={`p-2.5 rounded text-left border transition-colors flex items-center justify-between ${
                  isSelected
                    ? 'bg-neutral-900 border-blue-500/40 text-neutral-100'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <span>{role}</span>
                {isSelected && <span className="text-blue-400 text-xs">✓</span>}
              </button>
            );
          })}
        </div>

        {/* Custom role input */}
        <div className="pt-2">
          <div className="flex gap-2 max-w-sm">
            <input
              type="text"
              value={newRole}
              onChange={(e) => setNewRole(e.target.value)}
              placeholder="Add other role..."
              className="flex-1 p-2 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-100"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newRole.trim()) {
                  e.preventDefault();
                  if (!form.targetRoles.includes(newRole.trim())) {
                    setForm({ ...form, targetRoles: [...form.targetRoles, newRole.trim()] });
                  }
                  setNewRole('');
                }
              }}
            />
            <button
              type="button"
              onClick={() => {
                if (newRole.trim() && !form.targetRoles.includes(newRole.trim())) {
                  setForm({ ...form, targetRoles: [...form.targetRoles, newRole.trim()] });
                  setNewRole('');
                }
              }}
              className="px-3 py-1.5 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded"
            >
              Add
            </button>
          </div>
        </div>
      </div>

      {/* Relocation, Sponsorship & Threshold Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Relocation & Sponsorship Controls */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-purple-400" />
            <span>Relocation & Sponsorship Requirements</span>
          </h2>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded bg-neutral-900/60 border border-neutral-800 cursor-pointer">
              <div>
                <span className="font-medium text-neutral-200 block">Require Visa Sponsorship</span>
                <span className="text-neutral-400 text-[11px]">
                  Prioritize jobs explicitly offering employer sponsorship, work permits, or Iqama
                </span>
              </div>
              <input
                type="checkbox"
                checked={form.requireVisaSponsorship}
                onChange={(e) => setForm({ ...form, requireVisaSponsorship: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded bg-neutral-900/60 border border-neutral-800 cursor-pointer">
              <div>
                <span className="font-medium text-neutral-200 block">Willing to Relocate</span>
                <span className="text-neutral-400 text-[11px]">
                  Confirm candidate willingness to move abroad upon visa issuance
                </span>
              </div>
              <input
                type="checkbox"
                checked={form.willingToRelocate}
                onChange={(e) => setForm({ ...form, willingToRelocate: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded bg-neutral-900/60 border border-neutral-800 cursor-pointer">
              <div>
                <span className="font-medium text-neutral-200 block">Remote Jobs Allowed</span>
                <span className="text-neutral-400 text-[11px]">
                  Also accept global remote data entry & administrative roles
                </span>
              </div>
              <input
                type="checkbox"
                checked={form.remoteAllowed}
                onChange={(e) => setForm({ ...form, remoteAllowed: e.target.checked })}
                className="w-4 h-4 accent-emerald-500 rounded"
              />
            </label>
          </div>
        </div>

        {/* Minimum Match Score & Salary Expectations */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <span>Matching Threshold & Compensation</span>
          </h2>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-neutral-300 font-medium">Minimum Match Score Threshold</label>
                <span className="font-mono tabular-nums text-emerald-400 font-bold text-sm">
                  {form.minimumMatchScore}/100
                </span>
              </div>
              <input
                type="range"
                min="30"
                max="90"
                step="5"
                value={form.minimumMatchScore}
                onChange={(e) => setForm({ ...form, minimumMatchScore: Number(e.target.value) })}
                className="w-full accent-emerald-500"
              />
              <p className="text-[11px] text-neutral-400 mt-1">
                Only listings scoring at or above this threshold will enter the automated application pipeline.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-neutral-400 block mb-1">Minimum Salary Expected</label>
                <input
                  type="number"
                  min="0"
                  value={form.minimumSalaryExpected}
                  onChange={(e) => setForm({ ...form, minimumSalaryExpected: Number(e.target.value) })}
                  className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 font-mono"
                  placeholder="0 (any)"
                />
              </div>

              <div>
                <label className="text-neutral-400 block mb-1">Currency</label>
                <select
                  value={form.currency}
                  onChange={(e) => setForm({ ...form, currency: e.target.value })}
                  className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
                >
                  <option value="USD">USD ($)</option>
                  <option value="AED">AED (UAE Dirham)</option>
                  <option value="SAR">SAR (Saudi Riyal)</option>
                  <option value="QAR">QAR (Qatari Riyal)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Excluded Employers & Job Sources */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* Excluded Employers */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>Excluded Employers (Blacklist)</span>
          </h2>
          <p className="text-neutral-400 text-[11px]">
            The agent will automatically skip jobs from these companies.
          </p>

          <div className="flex flex-wrap gap-1.5">
            {form.excludedEmployers.map((emp, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-950/40 border border-rose-800/40 text-rose-300 text-xs"
              >
                <span>{emp}</span>
                <button
                  type="button"
                  onClick={() =>
                    setForm({
                      ...form,
                      excludedEmployers: form.excludedEmployers.filter((_, i) => i !== idx),
                    })
                  }
                  className="text-rose-400 hover:text-rose-200"
                >
                  ×
                </button>
              </span>
            ))}
          </div>

          <div className="flex gap-2 pt-2">
            <input
              type="text"
              value={newExcludedEmp}
              onChange={(e) => setNewExcludedEmp(e.target.value)}
              placeholder="Exclude company name..."
              className="flex-1 p-2 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-100"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newExcludedEmp.trim()) {
                  e.preventDefault();
                  setForm({
                    ...form,
                    excludedEmployers: [...form.excludedEmployers, newExcludedEmp.trim()],
                  });
                  setNewExcludedEmp('');
                }
              }}
            />
            <button
              type="button"
              onClick={() => {
                if (newExcludedEmp.trim()) {
                  setForm({
                    ...form,
                    excludedEmployers: [...form.excludedEmployers, newExcludedEmp.trim()],
                  });
                  setNewExcludedEmp('');
                }
              }}
              className="px-3 py-1.5 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded"
            >
              Add
            </button>
          </div>
        </div>

        {/* Enabled Job Sources */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-emerald-400" />
            <span>Active Job Source Integrations</span>
          </h2>
          <p className="text-neutral-400 text-[11px]">
            Free public job APIs and public career portals enabled for autonomous discovery.
          </p>

          <div className="space-y-2">
            {availableSources.map((source) => {
              const isEnabled = form.enabledSources.includes(source);
              return (
                <label
                  key={source}
                  className="flex items-center justify-between p-2 rounded bg-neutral-900 border border-neutral-800 cursor-pointer"
                >
                  <span className="text-neutral-300 font-medium">{source}</span>
                  <input
                    type="checkbox"
                    checked={isEnabled}
                    onChange={() => toggleSource(source)}
                    className="w-4 h-4 accent-emerald-500 rounded"
                  />
                </label>
              );
            })}
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-3 pt-2">
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50 cursor-pointer"
        >
          <Save className="w-3.5 h-3.5" />
          <span>{isSaving ? 'Saving...' : 'Save Job Rules & Re-Score Matches'}</span>
        </button>
      </div>
    </div>
  );
};
