import React, { useState } from 'react';
import {
  User,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  GraduationCap,
  Globe,
  Languages,
  Wrench,
  Award,
} from 'lucide-react';
import type { CandidateProfile, EducationItem, ExperienceItem, LanguageItem } from '../../types.ts';
import { updateProfile } from '../../utils/api.ts';

interface CandidateProfileViewProps {
  profile: CandidateProfile;
  onProfileUpdated: (updated: CandidateProfile) => void;
}

export const CandidateProfileView: React.FC<CandidateProfileViewProps> = ({
  profile,
  onProfileUpdated,
}) => {
  const [form, setForm] = useState<CandidateProfile>(profile);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [newSkill, setNewSkill] = useState('');
  const [newTool, setNewTool] = useState('');
  const [newCert, setNewCert] = useState('');
  const [newTitle, setNewTitle] = useState('');

  const handleSave = async () => {
    setIsSaving(true);
    setErrorMsg(null);
    setSaveSuccess(false);
    try {
      const res = await updateProfile(form);
      onProfileUpdated(res.profile);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update candidate profile.');
    } finally {
      setIsSaving(false);
    }
  };

  // Education handlers
  const addEducation = () => {
    const newItem: EducationItem = {
      id: `edu-${Date.now()}`,
      degree: 'Higher Secondary / Diploma / Bachelor',
      field: 'General Studies / Commerce / Science',
      institution: 'College / Institute Name',
      year: '2022',
      country: form.currentCountry || 'India',
    };
    setForm({ ...form, education: [...form.education, newItem] });
  };

  const removeEducation = (id: string) => {
    setForm({ ...form, education: form.education.filter((e) => e.id !== id) });
  };

  // Experience handlers
  const addExperience = () => {
    const newItem: ExperienceItem = {
      id: `exp-${Date.now()}`,
      title: 'Storekeeper / Data Operator',
      company: 'Logistics & Services Ltd',
      location: form.currentCity || 'City',
      startDate: '2022',
      endDate: '2024',
      isCurrent: false,
      highlights: ['Maintained daily documentation and spreadsheet inventory control logs.'],
    };
    setForm({ ...form, experience: [...form.experience, newItem] });
  };

  const removeExperience = (id: string) => {
    setForm({ ...form, experience: form.experience.filter((e) => e.id !== id) });
  };

  // Languages handler
  const addLanguage = () => {
    const newItem: LanguageItem = {
      id: `lang-${Date.now()}`,
      language: 'English',
      proficiency: 'Professional',
    };
    setForm({ ...form, languages: [...form.languages, newItem] });
  };

  const removeLanguage = (id: string) => {
    setForm({ ...form, languages: form.languages.filter((l) => l.id !== id) });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-neutral-100">Candidate Profile & Verified Credentials</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Review and fine-tune your structured profile. These verified details are strictly used to compute match scores and auto-generate truthful application packages.
          </p>
        </div>

        <button
          onClick={handleSave}
          disabled={isSaving}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50 shrink-0 cursor-pointer"
        >
          <Save className="w-3.5 h-3.5" />
          <span>{isSaving ? 'Saving Changes...' : 'Save Profile Changes'}</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 rounded bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Profile saved successfully. All job scores re-evaluated against your credentials.</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-3 rounded bg-rose-950/40 border border-rose-800/40 text-xs text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Basic Contact Info */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
        <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
          <User className="w-4 h-4 text-emerald-400" />
          <span>Personal & Contact Information</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="text-neutral-400 block mb-1">Full Legal Name</label>
            <input
              type="text"
              value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
            />
          </div>

          <div>
            <label className="text-neutral-400 block mb-1">Email Address</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
            />
          </div>

          <div>
            <label className="text-neutral-400 block mb-1">Phone Number (with Country Code)</label>
            <input
              type="text"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="+91 98765 43210"
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
            />
          </div>

          <div>
            <label className="text-neutral-400 block mb-1">Current City</label>
            <input
              type="text"
              value={form.currentCity}
              onChange={(e) => setForm({ ...form, currentCity: e.target.value })}
              placeholder="Mumbai"
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
            />
          </div>

          <div>
            <label className="text-neutral-400 block mb-1">Current Country of Residence</label>
            <input
              type="text"
              value={form.currentCountry}
              onChange={(e) => setForm({ ...form, currentCountry: e.target.value })}
              placeholder="India"
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
            />
          </div>

          <div>
            <label className="text-neutral-400 block mb-1">Total Years of Experience</label>
            <input
              type="number"
              step="0.5"
              min="0"
              max="40"
              value={form.totalYearsExperience}
              onChange={(e) => setForm({ ...form, totalYearsExperience: Number(e.target.value) })}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 font-mono"
            />
          </div>
        </div>

        <div>
          <label className="text-neutral-400 block mb-1 text-xs">Professional Summary</label>
          <textarea
            value={form.summary}
            onChange={(e) => setForm({ ...form, summary: e.target.value })}
            rows={3}
            className="w-full p-2.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 text-xs leading-relaxed"
          />
        </div>
      </div>

      {/* Target Titles & Vocational Categories */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
        <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-blue-400" />
          <span>Preferred Job Titles & Roles</span>
        </h2>

        <div className="flex flex-wrap gap-2">
          {form.preferredTitles.map((title, idx) => (
            <div
              key={idx}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-200"
            >
              <span>{title}</span>
              <button
                type="button"
                onClick={() =>
                  setForm({
                    ...form,
                    preferredTitles: form.preferredTitles.filter((_, i) => i !== idx),
                  })
                }
                className="text-neutral-500 hover:text-neutral-300"
              >
                ×
              </button>
            </div>
          ))}
        </div>

        <div className="flex gap-2 max-w-md">
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Add title (e.g. Document Controller, Storekeeper)"
            className="flex-1 p-2 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-100"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && newTitle.trim()) {
                e.preventDefault();
                setForm({ ...form, preferredTitles: [...form.preferredTitles, newTitle.trim()] });
                setNewTitle('');
              }
            }}
          />
          <button
            type="button"
            onClick={() => {
              if (newTitle.trim()) {
                setForm({ ...form, preferredTitles: [...form.preferredTitles, newTitle.trim()] });
                setNewTitle('');
              }
            }}
            className="px-3 py-1.5 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded transition-colors"
          >
            Add
          </button>
        </div>
      </div>

      {/* Skills & Software Tools */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Core Skills */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <Wrench className="w-4 h-4 text-emerald-400" />
            <span>Vocational & Technical Skills</span>
          </h2>

          <div className="flex flex-wrap gap-1.5">
            {form.skills.map((skill, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-300"
              >
                <span>{skill}</span>
                <button
                  type="button"
                  onClick={() =>
                    setForm({ ...form, skills: form.skills.filter((_, i) => i !== idx) })
                  }
                  className="text-neutral-500 hover:text-neutral-300"
                >
                  ×
                </button>
              </span>
            ))}
          </div>

          <div className="flex gap-2 pt-2">
            <input
              type="text"
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              placeholder="Add skill (e.g. Invoicing, Filing, Typing)"
              className="flex-1 p-2 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-100"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newSkill.trim()) {
                  e.preventDefault();
                  setForm({ ...form, skills: [...form.skills, newSkill.trim()] });
                  setNewSkill('');
                }
              }}
            />
            <button
              type="button"
              onClick={() => {
                if (newSkill.trim()) {
                  setForm({ ...form, skills: [...form.skills, newSkill.trim()] });
                  setNewSkill('');
                }
              }}
              className="px-3 py-1.5 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded"
            >
              Add
            </button>
          </div>
        </div>

        {/* Software Tools */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <Wrench className="w-4 h-4 text-blue-400" />
            <span>Software & Digital Tools</span>
          </h2>

          <div className="flex flex-wrap gap-1.5">
            {form.softwareTools.map((tool, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-300"
              >
                <span>{tool}</span>
                <button
                  type="button"
                  onClick={() =>
                    setForm({ ...form, softwareTools: form.softwareTools.filter((_, i) => i !== idx) })
                  }
                  className="text-neutral-500 hover:text-neutral-300"
                >
                  ×
                </button>
              </span>
            ))}
          </div>

          <div className="flex gap-2 pt-2">
            <input
              type="text"
              value={newTool}
              onChange={(e) => setNewTool(e.target.value)}
              placeholder="Add software (e.g. MS Excel, SAP, EDMS)"
              className="flex-1 p-2 rounded bg-neutral-900 border border-neutral-800 text-xs text-neutral-100"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newTool.trim()) {
                  e.preventDefault();
                  setForm({ ...form, softwareTools: [...form.softwareTools, newTool.trim()] });
                  setNewTool('');
                }
              }}
            />
            <button
              type="button"
              onClick={() => {
                if (newTool.trim()) {
                  setForm({ ...form, softwareTools: [...form.softwareTools, newTool.trim()] });
                  setNewTool('');
                }
              }}
              className="px-3 py-1.5 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded"
            >
              Add
            </button>
          </div>
        </div>
      </div>

      {/* Employment History */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-emerald-400" />
            <span>Verified Employment History</span>
          </h2>
          <button
            onClick={addExperience}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded text-neutral-200"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Work History</span>
          </button>
        </div>

        {form.experience.length === 0 ? (
          <div className="text-xs text-neutral-400 py-3">
            No employment entries yet. Click &quot;Add Work History&quot; to add your previous positions.
          </div>
        ) : (
          <div className="space-y-3">
            {form.experience.map((exp, idx) => (
              <div
                key={exp.id || idx}
                className="p-3.5 rounded bg-neutral-900/60 border border-neutral-800 text-xs space-y-2.5"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
                    <div>
                      <label className="text-neutral-400 block mb-0.5">Job Title</label>
                      <input
                        type="text"
                        value={exp.title}
                        onChange={(e) => {
                          const updated = [...form.experience];
                          updated[idx].title = e.target.value;
                          setForm({ ...form, experience: updated });
                        }}
                        className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                      />
                    </div>
                    <div>
                      <label className="text-neutral-400 block mb-0.5">Company Name</label>
                      <input
                        type="text"
                        value={exp.company}
                        onChange={(e) => {
                          const updated = [...form.experience];
                          updated[idx].company = e.target.value;
                          setForm({ ...form, experience: updated });
                        }}
                        className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                      />
                    </div>
                    <div>
                      <label className="text-neutral-400 block mb-0.5">Location</label>
                      <input
                        type="text"
                        value={exp.location}
                        onChange={(e) => {
                          const updated = [...form.experience];
                          updated[idx].location = e.target.value;
                          setForm({ ...form, experience: updated });
                        }}
                        className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                      />
                    </div>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <label className="text-neutral-400 block mb-0.5">Start Date</label>
                        <input
                          type="text"
                          value={exp.startDate}
                          onChange={(e) => {
                            const updated = [...form.experience];
                            updated[idx].startDate = e.target.value;
                            setForm({ ...form, experience: updated });
                          }}
                          className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                        />
                      </div>
                      <div className="flex-1">
                        <label className="text-neutral-400 block mb-0.5">End Date</label>
                        <input
                          type="text"
                          value={exp.endDate}
                          onChange={(e) => {
                            const updated = [...form.experience];
                            updated[idx].endDate = e.target.value;
                            setForm({ ...form, experience: updated });
                          }}
                          className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => removeExperience(exp.id)}
                    className="p-1.5 text-neutral-500 hover:text-rose-400 rounded transition-colors"
                    title="Remove Entry"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Education & Qualifications */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-purple-400" />
            <span>Education & Academic Credentials</span>
          </h2>
          <button
            onClick={addEducation}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded text-neutral-200"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Qualification</span>
          </button>
        </div>

        <div className="space-y-3">
          {form.education.map((edu, idx) => (
            <div
              key={edu.id || idx}
              className="p-3.5 rounded bg-neutral-900/60 border border-neutral-800 text-xs space-y-2.5"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
                  <div>
                    <label className="text-neutral-400 block mb-0.5">Degree / Certificate</label>
                    <input
                      type="text"
                      value={edu.degree}
                      onChange={(e) => {
                        const updated = [...form.education];
                        updated[idx].degree = e.target.value;
                        setForm({ ...form, education: updated });
                      }}
                      className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                    />
                  </div>
                  <div>
                    <label className="text-neutral-400 block mb-0.5">Institution / University</label>
                    <input
                      type="text"
                      value={edu.institution}
                      onChange={(e) => {
                        const updated = [...form.education];
                        updated[idx].institution = e.target.value;
                        setForm({ ...form, education: updated });
                      }}
                      className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                    />
                  </div>
                  <div>
                    <label className="text-neutral-400 block mb-0.5">Major / Field</label>
                    <input
                      type="text"
                      value={edu.field}
                      onChange={(e) => {
                        const updated = [...form.education];
                        updated[idx].field = e.target.value;
                        setForm({ ...form, education: updated });
                      }}
                      className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                    />
                  </div>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <label className="text-neutral-400 block mb-0.5">Graduation Year</label>
                      <input
                        type="text"
                        value={edu.year}
                        onChange={(e) => {
                          const updated = [...form.education];
                          updated[idx].year = e.target.value;
                          setForm({ ...form, education: updated });
                        }}
                        className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="text-neutral-400 block mb-0.5">Country</label>
                      <input
                        type="text"
                        value={edu.country}
                        onChange={(e) => {
                          const updated = [...form.education];
                          updated[idx].country = e.target.value;
                          setForm({ ...form, education: updated });
                        }}
                        className="w-full p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-100"
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => removeEducation(edu.id)}
                  className="p-1.5 text-neutral-500 hover:text-rose-400 rounded transition-colors"
                  title="Remove Qualification"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Languages */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
            <Languages className="w-4 h-4 text-emerald-400" />
            <span>Languages & Proficiencies</span>
          </h2>
          <button
            onClick={addLanguage}
            className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded text-neutral-200"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Language</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          {form.languages.map((lang, idx) => (
            <div
              key={lang.id || idx}
              className="p-2.5 rounded bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2 flex-1">
                <input
                  type="text"
                  value={lang.language}
                  onChange={(e) => {
                    const updated = [...form.languages];
                    updated[idx].language = e.target.value;
                    setForm({ ...form, languages: updated });
                  }}
                  className="p-1 rounded bg-neutral-950 border border-neutral-800 text-neutral-100 text-xs w-28"
                />
                <select
                  value={lang.proficiency}
                  onChange={(e) => {
                    const updated = [...form.languages];
                    updated[idx].proficiency = e.target.value as any;
                    setForm({ ...form, languages: updated });
                  }}
                  className="p-1 rounded bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs flex-1"
                >
                  <option value="Native">Native</option>
                  <option value="Fluent">Fluent</option>
                  <option value="Professional">Professional</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Basic">Basic</option>
                </select>
              </div>

              <button
                onClick={() => removeLanguage(lang.id)}
                className="text-neutral-500 hover:text-rose-400"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Floating or Bottom Save Bar */}
      <div className="flex items-center justify-end gap-3 pt-2">
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50 cursor-pointer"
        >
          <Save className="w-3.5 h-3.5" />
          <span>{isSaving ? 'Saving Changes...' : 'Save All Candidate Updates'}</span>
        </button>
      </div>
    </div>
  );
};
