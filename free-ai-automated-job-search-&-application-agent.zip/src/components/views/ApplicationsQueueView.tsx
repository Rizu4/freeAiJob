import React, { useState } from 'react';
import {
  Send,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Copy,
  Calendar,
  FileText,
  AlertOctagon,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import type { ApplicationRecord, ApplicationStatus } from '../../types.ts';
import { submitApplication, updateApplication } from '../../utils/api.ts';

interface ApplicationsQueueViewProps {
  applications: ApplicationRecord[];
  filterStatus?: ApplicationStatus | 'all' | 'manual-only' | 'auto-only' | 'in-progress' | 'submitted' | 'failed';
  title?: string;
  onRefresh: () => void;
}

export const ApplicationsQueueView: React.FC<ApplicationsQueueViewProps> = ({
  applications,
  filterStatus = 'all',
  title,
  onRefresh,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>(filterStatus);
  const [expandedAppId, setExpandedAppId] = useState<string | null>(null);
  const [isSubmittingId, setIsSubmittingId] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [statusUpdateSuccess, setStatusUpdateSuccess] = useState<string | null>(null);

  // Manual submission state
  const [manualConfirmRef, setManualConfirmRef] = useState<string>('');

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleAutoSubmit = async (appId: string) => {
    setIsSubmittingId(appId);
    try {
      const res = await submitApplication(appId);
      if (res.requiresManualAction) {
        setStatusUpdateSuccess(`Application placed in Manual Action Queue: ${res.reason}`);
      } else {
        setStatusUpdateSuccess(`Submitted successfully! Ref: ${res.confirmationRef}`);
      }
      onRefresh();
      setTimeout(() => setStatusUpdateSuccess(null), 5000);
    } catch (err: any) {
      console.error('Submit error:', err);
    } finally {
      setIsSubmittingId(null);
    }
  };

  const handleStatusChange = async (appId: string, newStatus: ApplicationStatus, notes?: string) => {
    try {
      await updateApplication(appId, {
        status: newStatus,
        notes: notes || undefined,
        confirmationRef: manualConfirmRef || undefined,
      });
      setStatusUpdateSuccess(`Status updated to "${newStatus}"`);
      setManualConfirmRef('');
      onRefresh();
      setTimeout(() => setStatusUpdateSuccess(null), 3000);
    } catch (err: any) {
      console.error('Failed to update status:', err);
    }
  };

  // Filter applications
  const filtered = applications.filter((app) => {
    if (activeFilter === 'manual-only') return app.status === 'Manual Action Required';
    if (activeFilter === 'auto-only') return app.submissionMode === 'automatic';
    if (activeFilter === 'in-progress') return app.status === 'Prepared';
    if (activeFilter === 'submitted') return app.status === 'Submitted' || app.status === 'Confirmation Pending';
    if (activeFilter === 'failed') return app.status === 'Failed';
    if (activeFilter !== 'all') return app.status.toLowerCase() === activeFilter.toLowerCase();
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-neutral-100">
            {title || 'Application Tracking & Action Pipelines'}
          </h1>
          <p className="text-xs text-neutral-400 mt-1">
            Tracking outcomes, follow-ups, and pre-filled copyable packages for external career portals requiring manual action.
          </p>
        </div>

        {/* Filter Segmented Control */}
        <div className="flex flex-wrap items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-lg text-xs">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-2.5 py-1 rounded transition-colors ${
              activeFilter === 'all' ? 'bg-neutral-800 text-neutral-100' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            All ({applications.length})
          </button>
          <button
            onClick={() => setActiveFilter('manual-only')}
            className={`px-2.5 py-1 rounded transition-colors ${
              activeFilter === 'manual-only'
                ? 'bg-amber-950/80 border border-amber-800/40 text-amber-300'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Manual Action ({applications.filter((a) => a.status === 'Manual Action Required').length})
          </button>
          <button
            onClick={() => setActiveFilter('in-progress')}
            className={`px-2.5 py-1 rounded transition-colors ${
              activeFilter === 'in-progress' ? 'bg-neutral-800 text-neutral-100' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Prepared ({applications.filter((a) => a.status === 'Prepared').length})
          </button>
          <button
            onClick={() => setActiveFilter('submitted')}
            className={`px-2.5 py-1 rounded transition-colors ${
              activeFilter === 'submitted' ? 'bg-neutral-800 text-emerald-400' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Submitted ({applications.filter((a) => a.status === 'Submitted').length})
          </button>
        </div>
      </div>

      {statusUpdateSuccess && (
        <div className="p-3 rounded bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusUpdateSuccess}</span>
        </div>
      )}

      {/* Applications List */}
      {filtered.length === 0 ? (
        <div className="p-12 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
          <Clock className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
          <h2 className="text-sm font-semibold text-neutral-200">No applications in this category</h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
            Applications will appear here automatically when the agent runs its scheduled cycle or when you click &quot;Prepare Application&quot; from matched vacancies.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((app) => {
            const isExpanded = expandedAppId === app.id;
            const isManual = app.status === 'Manual Action Required';
            const isSubmitted = app.status === 'Submitted';

            return (
              <div
                key={app.id}
                className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 transition-colors"
              >
                {/* Primary Row */}
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="text-base font-bold text-neutral-100">{app.jobTitle}</h2>
                        {/* Unboxed Metadata */}
                        <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 mt-1">
                          <span className="text-neutral-200 font-medium">{app.company}</span>
                          <span aria-hidden="true">·</span>
                          <span>{app.country}</span>
                          <span aria-hidden="true">·</span>
                          <span>Source: {app.jobSource}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono text-emerald-400 font-medium">
                            Score {app.matchScore}/100
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span
                          className={`px-2.5 py-1 rounded text-xs font-medium ${
                            isManual
                              ? 'text-amber-400 bg-amber-950/60 border border-amber-800/40'
                              : isSubmitted
                              ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40'
                              : 'text-neutral-300 bg-neutral-900 border border-neutral-800'
                          }`}
                        >
                          {app.status}
                        </span>
                      </div>
                    </div>

                    {/* Operational Notes / Reason */}
                    {app.notes && (
                      <div className="mt-2.5 text-xs text-neutral-300 flex items-start gap-1.5">
                        {isManual ? (
                          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4 text-neutral-500 shrink-0 mt-0.5" />
                        )}
                        <span>{app.notes}</span>
                      </div>
                    )}

                    {/* Dates Strip */}
                    <div className="mt-2 flex items-center gap-4 text-[11px] text-neutral-500 font-mono">
                      <span>Discovered: {new Date(app.dateDiscovered).toLocaleDateString()}</span>
                      {app.submissionDate && (
                        <span>Submitted: {new Date(app.submissionDate).toLocaleDateString()}</span>
                      )}
                      {app.confirmationRef && (
                        <span className="text-emerald-400 font-bold">
                          Ref: {app.confirmationRef}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions Right */}
                  <div className="flex items-center gap-2 shrink-0 pt-2 md:pt-0">
                    <button
                      onClick={() => setExpandedAppId(isExpanded ? null : app.id)}
                      className="px-3 py-1.5 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 rounded transition-colors flex items-center gap-1.5"
                    >
                      <span>{isExpanded ? 'Hide Pre-filled Data' : 'View Pre-filled Packet'}</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    <a
                      href={app.originalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-neutral-100 border border-neutral-700 rounded transition-colors flex items-center gap-1.5"
                    >
                      <span>Open Portal Link</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>

                    {app.status === 'Prepared' && (
                      <button
                        onClick={() => handleAutoSubmit(app.id)}
                        disabled={isSubmittingId === app.id}
                        className="px-3.5 py-1.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
                      >
                        {isSubmittingId === app.id ? 'Submitting...' : 'Dispatch Application'}
                      </button>
                    )}
                  </div>
                </div>

                {/* Expanded Pre-Filled Package Accordion */}
                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-neutral-800 space-y-4 text-xs">
                    <div className="p-3.5 rounded bg-neutral-900/80 border border-neutral-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="font-semibold text-neutral-200">
                          Pre-Filled Truthful Candidate Package
                        </div>
                        <span className="text-[11px] text-neutral-400">
                          Click any field to copy into clipboard
                        </span>
                      </div>

                      {app.preparedFormData && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
                          <button
                            type="button"
                            onClick={() => handleCopy(app.preparedFormData!.applicantName, 'name')}
                            className="p-2 text-left rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700"
                          >
                            <div className="text-[10px] text-neutral-400">Full Name</div>
                            <div className="font-medium text-neutral-200 truncate">
                              {app.preparedFormData.applicantName}
                            </div>
                            <div className="text-[10px] text-emerald-400 mt-0.5">
                              {copiedKey === 'name' ? 'Copied ✓' : 'Click to copy'}
                            </div>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleCopy(app.preparedFormData!.applicantEmail, 'email')}
                            className="p-2 text-left rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700"
                          >
                            <div className="text-[10px] text-neutral-400">Email</div>
                            <div className="font-medium text-neutral-200 truncate">
                              {app.preparedFormData.applicantEmail}
                            </div>
                            <div className="text-[10px] text-emerald-400 mt-0.5">
                              {copiedKey === 'email' ? 'Copied ✓' : 'Click to copy'}
                            </div>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleCopy(app.preparedFormData!.applicantPhone, 'phone')}
                            className="p-2 text-left rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700"
                          >
                            <div className="text-[10px] text-neutral-400">Phone</div>
                            <div className="font-medium text-neutral-200 truncate">
                              {app.preparedFormData.applicantPhone}
                            </div>
                            <div className="text-[10px] text-emerald-400 mt-0.5">
                              {copiedKey === 'phone' ? 'Copied ✓' : 'Click to copy'}
                            </div>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleCopy(app.preparedFormData!.currentLocation, 'location')}
                            className="p-2 text-left rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-700"
                          >
                            <div className="text-[10px] text-neutral-400">Current Location</div>
                            <div className="font-medium text-neutral-200 truncate">
                              {app.preparedFormData.currentLocation}
                            </div>
                            <div className="text-[10px] text-emerald-400 mt-0.5">
                              {copiedKey === 'location' ? 'Copied ✓' : 'Click to copy'}
                            </div>
                          </button>
                        </div>
                      )}

                      {/* Prepared Cover Letter */}
                      {app.preparedFormData?.coverLetter && (
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-neutral-400 text-[11px]">
                            <span>Tailored Truthful Cover Letter</span>
                            <button
                              type="button"
                              onClick={() => handleCopy(app.preparedFormData!.coverLetter, 'cl')}
                              className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
                            >
                              <Copy className="w-3 h-3" />
                              <span>{copiedKey === 'cl' ? 'Copied to Clipboard!' : 'Copy Letter'}</span>
                            </button>
                          </div>
                          <div className="p-3 rounded bg-neutral-950 border border-neutral-800 text-neutral-300 whitespace-pre-line leading-relaxed max-h-44 overflow-y-auto font-sans text-xs">
                            {app.preparedFormData.coverLetter}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Status Update Strip for user once completed */}
                    <div className="p-3 rounded bg-neutral-900 border border-neutral-800 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-neutral-400">Mark Status:</span>
                        <button
                          onClick={() => handleStatusChange(app.id, 'Submitted')}
                          className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-emerald-400 text-xs font-medium"
                        >
                          Submitted
                        </button>
                        <button
                          onClick={() => handleStatusChange(app.id, 'Interview')}
                          className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-purple-400 text-xs font-medium"
                        >
                          Interview
                        </button>
                        <button
                          onClick={() => handleStatusChange(app.id, 'Rejected')}
                          className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-rose-400 text-xs font-medium"
                        >
                          Rejected
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={manualConfirmRef}
                          onChange={(e) => setManualConfirmRef(e.target.value)}
                          placeholder="Submission Ref / Portal Code"
                          className="p-1.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-200 text-xs w-48"
                        />
                        <button
                          onClick={() =>
                            handleStatusChange(
                              app.id,
                              'Submitted',
                              manualConfirmRef ? `Manually submitted on employer portal. Ref: ${manualConfirmRef}` : undefined
                            )
                          }
                          className="px-3 py-1.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold hover:bg-emerald-500/30"
                        >
                          Save Record
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
