import React from 'react';
import {
  Briefcase,
  CheckCircle2,
  Plane,
  FileCheck,
  Send,
  AlertTriangle,
  XCircle,
  Calendar,
  ArrowRight,
  Upload,
  Globe2,
  Cpu,
  Clock,
  Shield,
  FileText,
} from 'lucide-react';
import type { DashboardStats, CandidateProfile, JobListing, ApplicationRecord } from '../../types.ts';
import type { NavigationTab } from '../Sidebar.tsx';

interface OverviewViewProps {
  stats: DashboardStats | null;
  profile: CandidateProfile;
  jobs: JobListing[];
  applications: ApplicationRecord[];
  onNavigate: (tab: NavigationTab) => void;
  onRunAgent: () => void;
  isRunningAgent: boolean;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  stats,
  profile,
  jobs,
  applications,
  onNavigate,
  onRunAgent,
  isRunningAgent,
}) => {
  const isProfileIncomplete = !profile.email || profile.fullName.includes('Pending');
  const manualActionApps = applications.filter((a) => a.status === 'Manual Action Required');
  const recentApplications = applications.slice(0, 4);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Alert banner if CV not yet uploaded */}
      {isProfileIncomplete && (
        <div className="p-4 rounded-lg bg-neutral-900 border border-amber-500/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-amber-500/10 text-amber-400">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-neutral-100">Upload your CV to activate full matching</h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                The agent parses your CV into a structured verified profile with ₹0 API costs.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('upload-cv')}
            className="px-3.5 py-1.5 text-xs font-semibold bg-amber-400 text-neutral-950 hover:bg-amber-300 rounded transition-colors whitespace-nowrap shrink-0"
          >
            Upload CV Now
          </button>
        </div>
      )}

      {/* Hero Agent Status Strip */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span>Agent Status:</span>
            <span className="font-semibold text-emerald-400">Active & Ready</span>
            <span aria-hidden="true">·</span>
            <span>Target: International Relocation & Sponsorship</span>
          </div>
          <h1 className="text-lg font-bold text-neutral-100 mt-1">
            Autonomous Job Search & Application Pipeline
          </h1>
          <p className="text-xs text-neutral-400 mt-1 max-w-2xl">
            Searching genuine public job sources worldwide (UAE, Qatar, Saudi Arabia, Poland, Germany, UK, Canada). Verified sponsorship detection with transparent 0-100 match scoring.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigate('schedule')}
            className="px-3 py-2 text-xs font-medium text-neutral-300 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded transition-colors"
          >
            Configure Schedule
          </button>
          <button
            onClick={onRunAgent}
            disabled={isRunningAgent}
            className="px-4 py-2 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
          >
            {isRunningAgent ? 'Running Agent...' : 'Run Agent Cycle Now'}
          </button>
        </div>
      </div>

      {/* Key Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Jobs Discovered</span>
            <Globe2 className="w-4 h-4 text-neutral-500" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-neutral-100">
            {stats?.jobsDiscovered ?? jobs.length}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">From verified public feeds</div>
        </div>

        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Profile Matches</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-neutral-100">
            {stats?.jobsMatchingProfile ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">Score ≥ minimum threshold</div>
        </div>

        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Visa Sponsorship</span>
            <Plane className="w-4 h-4 text-blue-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-neutral-100">
            {stats?.sponsorshipIdentified ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">Verified employer sponsored</div>
        </div>

        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Manual Action Queue</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-amber-400">
            {stats?.manualActionRequired ?? manualActionApps.length}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">Portals requiring 1-click submit</div>
        </div>

        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Applications Prepared</span>
            <FileCheck className="w-4 h-4 text-neutral-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-neutral-100">
            {stats?.applicationsPrepared ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">Truthful CV + cover letter ready</div>
        </div>

        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Submitted Applications</span>
            <Send className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-emerald-400">
            {stats?.applicationsSubmitted ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">Directly authorized submissions</div>
        </div>

        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Interviews Recorded</span>
            <Calendar className="w-4 h-4 text-purple-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono tabular-nums text-purple-400">
            {stats?.interviewInvitations ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">Positive employer callbacks</div>
        </div>

        <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800">
          <div className="flex items-center justify-between text-neutral-400 text-xs">
            <span>Last Successful Run</span>
            <Clock className="w-4 h-4 text-neutral-500" />
          </div>
          <div className="mt-2 text-sm font-semibold font-mono text-neutral-200 truncate">
            {stats?.lastSuccessfulRun
              ? new Date(stats.lastSuccessfulRun).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : 'Pending'}
          </div>
          <div className="mt-1 text-[11px] text-neutral-400">
            Schedule: {stats?.nextScheduledRun || 'Active'}
          </div>
        </div>
      </div>

      {/* 2-Column Split: Manual Action Alert + Fast Workflow */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Manual Action Queue Spotlights */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-neutral-100">Manual Action Required</h2>
              <p className="text-xs text-neutral-400">
                Jobs that require candidate portal login, CAPTCHA, or Workday forms. Pre-filled application packets are ready.
              </p>
            </div>
            <button
              onClick={() => onNavigate('manual-action')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1"
            >
              <span>View All ({manualActionApps.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {manualActionApps.length === 0 ? (
            <div className="p-8 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
              <CheckCircle2 className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
              <div className="text-sm font-medium text-neutral-200">No manual actions pending</div>
              <p className="text-xs text-neutral-400 mt-1">
                All eligible applications are processed or in automated queues.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {manualActionApps.slice(0, 3).map((app) => (
                <div
                  key={app.id}
                  className="p-4 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <span className="text-neutral-300 font-medium">{app.company}</span>
                        <span aria-hidden="true">·</span>
                        <span>{app.country}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums text-emerald-400 font-medium">
                          {app.matchScore}/100 Match
                        </span>
                      </div>
                      <h3 className="text-sm font-semibold text-neutral-100 mt-1">{app.jobTitle}</h3>
                      <p className="text-xs text-amber-400/90 mt-1.5 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>{app.notes}</span>
                      </p>
                    </div>

                    <button
                      onClick={() => onNavigate('manual-action')}
                      className="px-3 py-1.5 text-xs font-medium text-neutral-100 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 rounded transition-colors whitespace-nowrap shrink-0"
                    >
                      Complete in 1-Click
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Recent Application History */}
          <div className="pt-2">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-neutral-100">Recent Applications Pipeline</h2>
              <button
                onClick={() => onNavigate('submitted')}
                className="text-xs text-neutral-400 hover:text-neutral-200"
              >
                View Pipeline
              </button>
            </div>

            <div className="rounded-lg bg-neutral-950 border border-neutral-800 divide-y divide-neutral-800">
              {recentApplications.map((app) => (
                <div key={app.id} className="p-3.5 flex items-center justify-between gap-4 text-xs">
                  <div className="truncate">
                    <div className="font-medium text-neutral-200 truncate">{app.jobTitle}</div>
                    <div className="text-neutral-400 text-[11px] flex items-center gap-2 mt-0.5">
                      <span>{app.company}</span>
                      <span aria-hidden="true">·</span>
                      <span>{app.country}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-neutral-400">
                        Score: {app.matchScore}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                        app.status === 'Submitted'
                          ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40'
                          : app.status === 'Manual Action Required'
                          ? 'text-amber-400 bg-amber-950/60 border border-amber-800/40'
                          : 'text-neutral-400 bg-neutral-900 border border-neutral-800'
                      }`}
                    >
                      {app.status}
                    </span>
                    <a
                      href={app.originalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-neutral-400 hover:text-neutral-200"
                    >
                      Source ↗
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Guided 4-Step Automation Flow & System Invariants */}
        <div className="space-y-4">
          <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4">
            <h2 className="text-sm font-semibold text-neutral-100">Workflow & Operational Guide</h2>

            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-mono font-bold text-[11px] shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <div className="font-medium text-neutral-200">Upload & Verify CV</div>
                  <p className="text-neutral-400 mt-0.5">
                    Extracts qualifications, past roles, and skills truthfully without hallucinations.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-neutral-800 text-neutral-300 flex items-center justify-center font-mono font-bold text-[11px] shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <div className="font-medium text-neutral-200">Set Preferences & Countries</div>
                  <p className="text-neutral-400 mt-0.5">
                    Target UAE, Saudi Arabia, Qatar, Poland, Germany, UK, etc. with visa sponsorship requirement.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-neutral-800 text-neutral-300 flex items-center justify-center font-mono font-bold text-[11px] shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <div className="font-medium text-neutral-200">Autonomous Search & Scoring</div>
                  <p className="text-neutral-400 mt-0.5">
                    Agent discovers listings and transparently scores match from 0 to 100.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-neutral-800 text-neutral-300 flex items-center justify-center font-mono font-bold text-[11px] shrink-0 mt-0.5">
                  4
                </div>
                <div>
                  <div className="font-medium text-neutral-200">Apply & Complete Actions</div>
                  <p className="text-neutral-400 mt-0.5">
                    Permitted channels are auto-applied; complex portals get pre-filled data.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Privacy and Zero Cost Guarantee */}
          <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-neutral-200 font-medium">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>₹0 Zero Cost & Privacy Invariants</span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              This system runs locally or on your own free GitHub repository (<strong className="text-neutral-300">free-ai-job</strong>). It never shares your CV with recruiters without your command and uses free public endpoints.
            </p>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('privacy')}
                className="text-[11px] text-emerald-400 hover:text-emerald-300"
              >
                Inspect Privacy & Export Data →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
