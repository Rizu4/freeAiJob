import React, { useState } from 'react';
import { Upload, FileText, CheckCircle2, AlertCircle, Loader2, ArrowRight, ShieldCheck } from 'lucide-react';
import type { CandidateProfile } from '../../types.ts';
import { parseCv, updateProfile } from '../../utils/api.ts';

interface UploadCvViewProps {
  currentProfile: CandidateProfile;
  onProfileUpdated: (profile: CandidateProfile) => void;
  onNavigateToProfile: () => void;
}

export const UploadCvView: React.FC<UploadCvViewProps> = ({
  currentProfile,
  onProfileUpdated,
  onNavigateToProfile,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload');
  const [pastedText, setPastedText] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [parsedPreview, setParsedPreview] = useState<CandidateProfile | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setErrorMsg(null);
    }
  };

  const handleParse = async () => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (activeTab === 'upload' && !selectedFile) {
      setErrorMsg('Please select a PDF, DOCX, or TXT file to upload.');
      return;
    }
    if (activeTab === 'paste' && !pastedText.trim()) {
      setErrorMsg('Please paste your CV text into the box.');
      return;
    }

    setIsParsing(true);
    try {
      if (activeTab === 'upload' && selectedFile) {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64Data = (reader.result as string).split(',')[1];
          try {
            const result = await parseCv({
              fileName: selectedFile.name,
              fileBase64: base64Data,
              mimeType: selectedFile.type || 'application/pdf',
            });
            setParsedPreview(result.profile);
            setSuccessMsg('CV analyzed and structured successfully. Review below before saving.');
          } catch (err: any) {
            setErrorMsg(err.message || 'Failed to extract CV information.');
          } finally {
            setIsParsing(false);
          }
        };
        reader.onerror = () => {
          setErrorMsg('Error reading selected file.');
          setIsParsing(false);
        };
        reader.readAsDataURL(selectedFile);
      } else {
        const result = await parseCv({
          cvText: pastedText,
          fileName: 'Pasted_CV_Text.txt',
        });
        setParsedPreview(result.profile);
        setSuccessMsg('CV parsed successfully. Review below before saving.');
        setIsParsing(false);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error parsing CV.');
      setIsParsing(false);
    }
  };

  const handleSaveToProfile = async () => {
    if (!parsedPreview) return;
    setIsSaving(true);
    try {
      const res = await updateProfile(parsedPreview);
      onProfileUpdated(res.profile);
      setSuccessMsg('Candidate profile saved and active! All job match scores have been updated.');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save profile.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-lg font-bold text-neutral-100">Upload & Parse Candidate CV</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Upload your existing CV in PDF, DOCX, or text format. The system automatically extracts verified contact details, skills, experience, education, and language proficiencies without hallucinations.
        </p>
      </div>

      {/* Input Mode Selector */}
      <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-lg w-fit">
        <button
          onClick={() => setActiveTab('upload')}
          className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
            activeTab === 'upload' ? 'bg-neutral-800 text-neutral-100' : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          File Upload (PDF / DOCX)
        </button>
        <button
          onClick={() => setActiveTab('paste')}
          className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
            activeTab === 'paste' ? 'bg-neutral-800 text-neutral-100' : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Paste CV Text
        </button>
      </div>

      {/* Upload Zone */}
      {activeTab === 'upload' ? (
        <div className="p-8 rounded-lg bg-neutral-950 border-2 border-dashed border-neutral-800 hover:border-neutral-700 text-center transition-colors">
          <input
            type="file"
            id="cv-file-input"
            accept=".pdf,.docx,.doc,.txt"
            onChange={handleFileChange}
            className="hidden"
          />
          <label htmlFor="cv-file-input" className="cursor-pointer block">
            <Upload className="w-8 h-8 text-neutral-500 mx-auto mb-3" />
            <div className="text-sm font-medium text-neutral-200">
              {selectedFile ? selectedFile.name : 'Click to select or drag and drop your CV'}
            </div>
            <div className="text-xs text-neutral-400 mt-1">
              Supports PDF, DOCX, TXT up to 10MB
            </div>
          </label>
        </div>
      ) : (
        <div className="space-y-2">
          <textarea
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
            rows={10}
            placeholder="Paste the full text of your CV here (Name, contact details, work history, skills, education, languages)..."
            className="w-full p-4 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 font-mono placeholder:text-neutral-600 focus:outline-none focus:border-neutral-700 resize-y"
          />
        </div>
      )}

      {/* Parse Trigger Button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-neutral-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Truthfulness Guarantee: Zero fabricated experience or false certificates.</span>
        </div>

        <button
          onClick={handleParse}
          disabled={isParsing || (activeTab === 'upload' && !selectedFile) || (activeTab === 'paste' && !pastedText.trim())}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50 cursor-pointer"
        >
          {isParsing ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Parsing CV...</span>
            </>
          ) : (
            <>
              <FileText className="w-3.5 h-3.5" />
              <span>Extract & Build Profile</span>
            </>
          )}
        </button>
      </div>

      {/* Feedback Messages */}
      {errorMsg && (
        <div className="p-3.5 rounded bg-rose-950/30 border border-rose-800/40 text-xs text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 rounded bg-emerald-950/30 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Parsed Results Preview & Review */}
      {parsedPreview && (
        <div className="p-6 rounded-lg bg-neutral-950 border border-neutral-800 space-y-5">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <div>
              <h2 className="text-sm font-semibold text-neutral-100">Review Extracted Profile Data</h2>
              <p className="text-xs text-neutral-400">
                Verify accuracy before saving into your autonomous application profile.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleSaveToProfile}
                disabled={isSaving}
                className="px-4 py-1.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
              >
                {isSaving ? 'Saving...' : 'Confirm & Save Profile'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-neutral-400 block mb-1">Full Name</label>
              <input
                type="text"
                value={parsedPreview.fullName}
                onChange={(e) => setParsedPreview({ ...parsedPreview, fullName: e.target.value })}
                className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
              />
            </div>
            <div>
              <label className="text-neutral-400 block mb-1">Email Address</label>
              <input
                type="email"
                value={parsedPreview.email}
                onChange={(e) => setParsedPreview({ ...parsedPreview, email: e.target.value })}
                className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
              />
            </div>
            <div>
              <label className="text-neutral-400 block mb-1">Phone Number</label>
              <input
                type="text"
                value={parsedPreview.phone}
                onChange={(e) => setParsedPreview({ ...parsedPreview, phone: e.target.value })}
                className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
              />
            </div>
            <div>
              <label className="text-neutral-400 block mb-1">Current Country & City</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={parsedPreview.currentCity}
                  onChange={(e) => setParsedPreview({ ...parsedPreview, currentCity: e.target.value })}
                  placeholder="City"
                  className="w-1/2 p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
                />
                <input
                  type="text"
                  value={parsedPreview.currentCountry}
                  onChange={(e) => setParsedPreview({ ...parsedPreview, currentCountry: e.target.value })}
                  placeholder="Country"
                  className="w-1/2 p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="text-neutral-400 block mb-1 text-xs">Summary</label>
            <textarea
              value={parsedPreview.summary}
              onChange={(e) => setParsedPreview({ ...parsedPreview, summary: e.target.value })}
              rows={3}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 text-xs"
            />
          </div>

          {/* Skills Breakdown */}
          <div>
            <label className="text-neutral-400 block mb-1 text-xs">Extracted Skills (comma-separated)</label>
            <input
              type="text"
              value={parsedPreview.skills.join(', ')}
              onChange={(e) =>
                setParsedPreview({
                  ...parsedPreview,
                  skills: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                })
              }
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 text-xs"
            />
          </div>

          {/* Software Tools */}
          <div>
            <label className="text-neutral-400 block mb-1 text-xs">Software & Tools</label>
            <input
              type="text"
              value={parsedPreview.softwareTools.join(', ')}
              onChange={(e) =>
                setParsedPreview({
                  ...parsedPreview,
                  softwareTools: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                })
              }
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 text-xs"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              onClick={onNavigateToProfile}
              className="text-xs text-neutral-400 hover:text-neutral-200"
            >
              Go to Full Profile Editor →
            </button>
            <button
              onClick={handleSaveToProfile}
              disabled={isSaving}
              className="px-4 py-2 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
            >
              {isSaving ? 'Saving...' : 'Save & Update Matching System'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
