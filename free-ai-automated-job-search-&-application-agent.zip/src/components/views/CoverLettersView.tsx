import React, { useState } from 'react';
import {
  FileText,
  Sparkles,
  Download,
  Copy,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Building2,
  MapPin,
  RefreshCw,
} from 'lucide-react';
import type { CandidateProfile, JobListing, CoverLetterRecord } from '../../types.ts';
import { generateCoverLetter } from '../../utils/api.ts';

interface CoverLettersViewProps {
  profile: CandidateProfile;
  jobs: JobListing[];
  preselectedJob?: JobListing | null;
}

export const CoverLettersView: React.FC<CoverLettersViewProps> = ({
  profile,
  jobs,
  preselectedJob,
}) => {
  const [selectedJobId, setSelectedJobId] = useState<string>(preselectedJob ? preselectedJob.id : '');
  const [customTitle, setCustomTitle] = useState<string>(preselectedJob ? preselectedJob.title : '');
  const [customCompany, setCustomCompany] = useState<string>(preselectedJob ? preselectedJob.company : '');
  const [customCountry, setCustomCountry] = useState<string>(preselectedJob ? preselectedJob.country : 'United Arab Emirates');
  const [customJobDesc, setCustomJobDesc] = useState<string>(preselectedJob ? preselectedJob.description : '');

  const [generatedLetter, setGeneratedLetter] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSelectJob = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const jId = e.target.value;
    setSelectedJobId(jId);
    const found = jobs.find((j) => j.id === jId);
    if (found) {
      setCustomTitle(found.title);
      setCustomCompany(found.company);
      setCustomCountry(found.country);
      setCustomJobDesc(found.description);
    }
  };

  const handleGenerate = async () => {
    if (!customTitle || !customCompany) {
      setErrorMsg('Please specify both the Job Title and Company Name.');
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);
    try {
      const res = await generateCoverLetter({
        jobId: selectedJobId || undefined,
        jobTitle: customTitle,
        company: customCompany,
        country: customCountry,
        jobDescription: customJobDesc,
      });

      setGeneratedLetter(res.coverLetter.content);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error generating tailored cover letter.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedLetter);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadTxt = () => {
    const element = document.createElement('a');
    const file = new Blob([generatedLetter], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `Cover_Letter_${customCompany.replace(/\s+/g, '_')}_${customTitle.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-lg font-bold text-neutral-100">Tailored Cover Letter Generator</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Synthesizes verified credentials from your CV with specific employer vacancies. Generates concise, professional letters without hallucinations or fabricated claims.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Col: Target Job Configuration */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
            <h2 className="text-sm font-semibold text-neutral-200">Job & Employer Target</h2>
            <span className="text-neutral-400">Step 1</span>
          </div>

          {/* Quick Dropdown of discovered jobs */}
          <div>
            <label className="text-neutral-400 block mb-1">Pick from Discovered Jobs (Optional)</label>
            <select
              value={selectedJobId}
              onChange={handleSelectJob}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-neutral-700"
            >
              <option value="">-- Or enter custom job details below --</option>
              {jobs.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.title} · {j.company} ({j.country})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-neutral-400 block mb-1">Target Job Title *</label>
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder="e.g. Document Controller, Data Entry Operator"
                className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
              />
            </div>

            <div>
              <label className="text-neutral-400 block mb-1">Company / Employer Name *</label>
              <input
                type="text"
                value={customCompany}
                onChange={(e) => setCustomCompany(e.target.value)}
                placeholder="e.g. Al-Futtaim Logistics, DHL, Zalando"
                className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
              />
            </div>

            <div>
              <label className="text-neutral-400 block mb-1">Destination Country</label>
              <input
                type="text"
                value={customCountry}
                onChange={(e) => setCustomCountry(e.target.value)}
                placeholder="e.g. United Arab Emirates, Germany, Poland"
                className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100"
              />
            </div>

            <div>
              <label className="text-neutral-400 block mb-1">Job Description or Key Duties</label>
              <textarea
                value={customJobDesc}
                onChange={(e) => setCustomJobDesc(e.target.value)}
                rows={5}
                placeholder="Paste key duties or job description here to align your skills..."
                className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 resize-y"
              />
            </div>
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded bg-rose-950/40 border border-rose-800/40 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={isGenerating || !customTitle || !customCompany}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Crafting Verified Cover Letter...</span>
              </>
            ) : (
              <>
                <FileText className="w-4 h-4" />
                <span>Generate Tailored Cover Letter</span>
              </>
            )}
          </button>
        </div>

        {/* Right Col: Letter Preview & Output */}
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h2 className="text-sm font-semibold text-neutral-200">Generated Letter Preview</h2>
              {generatedLetter && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 rounded transition-colors flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copied ? 'Copied!' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleDownloadTxt}
                    className="px-2.5 py-1 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-800 rounded transition-colors flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download TXT</span>
                  </button>
                </div>
              )}
            </div>

            {generatedLetter ? (
              <div className="mt-3">
                <textarea
                  value={generatedLetter}
                  onChange={(e) => setGeneratedLetter(e.target.value)}
                  rows={14}
                  className="w-full p-4 rounded bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs leading-relaxed font-sans focus:outline-none focus:border-neutral-700 resize-y whitespace-pre-line"
                />
              </div>
            ) : (
              <div className="p-12 text-center text-xs text-neutral-400 mt-6">
                <FileText className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                <p>Fill in the target employer details and click &quot;Generate Tailored Cover Letter&quot;.</p>
              </div>
            )}
          </div>

          <div className="p-3 rounded bg-neutral-900/60 border border-neutral-800 text-[11px] text-neutral-400">
            <span className="font-semibold text-neutral-300">Truthfulness Constraint: </span>
            The letter only references verified skills ({profile.skills.slice(0, 3).join(', ')}) and states your accurate country of origin ({profile.currentCountry}).
          </div>
        </div>
      </div>
    </div>
  );
};
