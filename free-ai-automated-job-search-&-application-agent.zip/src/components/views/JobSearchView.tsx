import React, { useState } from 'react';
import {
  Search,
  Globe2,
  Filter,
  ShieldCheck,
  Bookmark,
  ExternalLink,
  Loader2,
  Eye,
  CheckCircle2,
  FileCheck,
  AlertTriangle,
} from 'lucide-react';
import type { JobListing, CandidateProfile, JobPreferences } from '../../types.ts';
import { triggerJobSearch, prepareApplication } from '../../utils/api.ts';
import { JobDetailModal } from '../JobDetailModal.tsx';

interface JobSearchViewProps {
  jobs: JobListing[];
  profile: CandidateProfile;
  preferences: JobPreferences;
  savedJobIds: Set<string>;
  onToggleSaveJob: (jobId: string) => void;
  onRefreshJobs: () => void;
  onNavigateToCoverLetter: (job: JobListing) => void;
  onApplicationCreated: () => void;
}

export const JobSearchView: React.FC<JobSearchViewProps> = ({
  jobs,
  profile,
  preferences,
  savedJobIds,
  onToggleSaveJob,
  onRefreshJobs,
  onNavigateToCoverLetter,
  onApplicationCreated,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [sponsorshipOnly, setSponsorshipOnly] = useState<boolean>(false);
  const [minScoreFilter, setMinScoreFilter] = useState<number>(0);
  const [isSearchingLive, setIsSearchingLive] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  // Modal inspection state
  const [inspectJob, setInspectJob] = useState<JobListing | null>(null);
  const [isPreparingId, setIsPreparingId] = useState<string | null>(null);

  const handleLiveSearch = async () => {
    setIsSearchingLive(true);
    setFeedbackMsg(null);
    try {
      const res = await triggerJobSearch(
        searchQuery || preferences.targetRoles.join(', '),
        selectedCountry !== 'all' ? [selectedCountry] : preferences.targetCountries
      );
      setFeedbackMsg(`Search completed! Discovered ${res.newJobsDiscovered} new listings across authorized public feeds.`);
      onRefreshJobs();
      setTimeout(() => setFeedbackMsg(null), 5000);
    } catch (err: any) {
      setFeedbackMsg(`Error running search: ${err.message}`);
    } finally {
      setIsSearchingLive(false);
    }
  };

  const handlePrepareApp = async (jobId: string) => {
    setIsPreparingId(jobId);
    try {
      await prepareApplication(jobId);
      onApplicationCreated();
      setFeedbackMsg('Application prepared and added to pipeline queue!');
      setTimeout(() => setFeedbackMsg(null), 4000);
    } catch (err: any) {
      console.error('Failed to prepare application:', err);
    } finally {
      setIsPreparingId(null);
    }
  };

  // Filter listings
  const filteredJobs = jobs.filter((job) => {
    if (selectedCountry !== 'all' && job.country.toLowerCase() !== selectedCountry.toLowerCase()) {
      return false;
    }
    if (sponsorshipOnly && !job.visaSponsorshipEvidence?.hasSponsorship) {
      return false;
    }
    if (minScoreFilter > 0 && job.matchScore < minScoreFilter) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inTitle = job.title.toLowerCase().includes(q);
      const inCompany = job.company.toLowerCase().includes(q);
      const inDesc = job.description.toLowerCase().includes(q);
      if (!inTitle && !inCompany && !inDesc) return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Title & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-neutral-100">International Job Discovery Engine</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Aggregating authorized public APIs (Arbeitnow, Jobicy, Remotive) and international employment portals offering verified visa sponsorship.
          </p>
        </div>

        <button
          onClick={handleLiveSearch}
          disabled={isSearchingLive}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50 shrink-0 cursor-pointer"
        >
          {isSearchingLive ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Querying Public APIs...</span>
            </>
          ) : (
            <>
              <Globe2 className="w-3.5 h-3.5" />
              <span>Query Public Sources Now</span>
            </>
          )}
        </button>
      </div>

      {feedbackMsg && (
        <div className="p-3 rounded bg-neutral-900 border border-neutral-700 text-xs text-neutral-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Filter Bar */}
      <div className="p-4 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Search Query */}
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by title, company, skills..."
              className="w-full pl-8 pr-3 py-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder:text-neutral-500 focus:outline-none focus:border-neutral-700"
            />
          </div>

          {/* Country Filter */}
          <div>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-200 focus:outline-none focus:border-neutral-700"
            >
              <option value="all">All Countries ({jobs.length})</option>
              {preferences.targetCountries.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Minimum Score Slider */}
          <div className="flex items-center gap-2 px-2">
            <span className="text-neutral-400 whitespace-nowrap">Min Score:</span>
            <input
              type="range"
              min="0"
              max="90"
              step="5"
              value={minScoreFilter}
              onChange={(e) => setMinScoreFilter(Number(e.target.value))}
              className="flex-1 accent-emerald-500"
            />
            <span className="font-mono tabular-nums text-neutral-200 font-bold w-7 text-right">
              {minScoreFilter}
            </span>
          </div>

          {/* Sponsorship Checkbox */}
          <label className="flex items-center gap-2 px-3 py-2 rounded bg-neutral-900 border border-neutral-800 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={sponsorshipOnly}
              onChange={(e) => setSponsorshipOnly(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded"
            />
            <span className="text-neutral-300 font-medium">Only Visa Sponsored</span>
          </label>
        </div>
      </div>

      {/* Results Count & Source Tag */}
      <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
        <div>
          Showing <span className="font-mono font-bold text-neutral-200">{filteredJobs.length}</span> verified vacancies
        </div>
        <div>
          Active Sources: <span className="text-neutral-300">Arbeitnow, Jobicy, Remotive, Gulf Public Feeds</span>
        </div>
      </div>

      {/* Job Cards Grid */}
      {filteredJobs.length === 0 ? (
        <div className="p-12 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
          <Globe2 className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
          <h2 className="text-sm font-semibold text-neutral-200">No matching vacancies found</h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
            Try lowering your match score filter or clicking &quot;Query Public Sources Now&quot; to fetch fresh listings.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredJobs.map((job) => {
            const isSaved = savedJobIds.has(job.id);
            const isAuto = job.applicationMethod === 'auto_permitted';

            return (
              <div
                key={job.id}
                className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 transition-colors flex flex-col justify-between"
              >
                <div>
                  {/* Leading Title & Bookmark */}
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-sm font-bold text-neutral-100 hover:text-emerald-300 transition-colors">
                        {job.title}
                      </h2>
                      {/* Unboxed Metadata with · separator */}
                      <div className="flex items-center gap-2 text-xs text-neutral-400 mt-1">
                        <span className="text-neutral-300 font-medium">{job.company}</span>
                        <span aria-hidden="true">·</span>
                        <span>{job.location}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-neutral-300">{job.country}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => onToggleSaveJob(job.id)}
                        title={isSaved ? 'Remove from Saved' : 'Save Job'}
                        className={`p-1.5 rounded transition-colors ${
                          isSaved
                            ? 'text-amber-400 bg-amber-950/40 border border-amber-800/40'
                            : 'text-neutral-500 hover:text-neutral-300 hover:bg-neutral-900'
                        }`}
                      >
                        <Bookmark className="w-4 h-4 fill-current" />
                      </button>

                      {/* Transparent Match Score */}
                      <div className="flex flex-col items-end">
                        <span className="font-mono tabular-nums text-sm font-bold text-emerald-400">
                          {job.matchScore}/100
                        </span>
                        <span className="text-[10px] text-neutral-400">Match</span>
                      </div>
                    </div>
                  </div>

                  {/* Visa Sponsorship Evidence snippet */}
                  <div className="mt-3 p-2.5 rounded bg-neutral-900/70 border border-neutral-800/80 text-xs">
                    <div className="flex items-center gap-1.5 text-neutral-300 font-medium mb-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Sponsorship Evidence</span>
                    </div>
                    <p className="text-neutral-400 text-[11px] leading-relaxed line-clamp-2">
                      {job.visaSponsorshipEvidence?.evidenceSnippet || 'Standard international permit required.'}
                    </p>
                  </div>

                  {/* Excerpt of description */}
                  <p className="text-xs text-neutral-400 mt-3 line-clamp-3 leading-relaxed">
                    {job.description}
                  </p>
                </div>

                {/* Footer Controls */}
                <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[11px] font-medium px-2 py-0.5 rounded ${
                        isAuto
                          ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40'
                          : 'text-amber-400 bg-amber-950/60 border border-amber-800/40'
                      }`}
                    >
                      {isAuto ? 'Auto Submit Permitted' : 'Manual Portal Action'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setInspectJob(job)}
                      className="px-2.5 py-1.5 text-xs text-neutral-300 hover:text-neutral-100 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded transition-colors flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3" />
                      <span>Inspect</span>
                    </button>

                    <button
                      onClick={() => handlePrepareApp(job.id)}
                      disabled={isPreparingId === job.id}
                      className="px-3 py-1.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
                    >
                      {isPreparingId === job.id ? 'Preparing...' : 'Prepare Application'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Inspect Modal */}
      <JobDetailModal
        job={inspectJob}
        profile={profile}
        isOpen={Boolean(inspectJob)}
        onClose={() => setInspectJob(null)}
        onPrepareApplication={handlePrepareApp}
        onGenerateCoverLetter={(job) => {
          setInspectJob(null);
          onNavigateToCoverLetter(job);
        }}
        isPreparing={Boolean(isPreparingId)}
      />
    </div>
  );
};
