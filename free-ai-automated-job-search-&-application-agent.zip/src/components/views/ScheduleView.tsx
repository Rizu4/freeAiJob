import React, { useState } from 'react';
import {
  CalendarCheck,
  Play,
  Pause,
  Clock,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Github,
  Save,
  Loader2,
} from 'lucide-react';
import type { AutomationScheduleConfig } from '../../types.ts';
import { updateSchedule } from '../../utils/api.ts';

interface ScheduleViewProps {
  schedule: AutomationScheduleConfig;
  onScheduleUpdated: (updated: AutomationScheduleConfig) => void;
  onRunAgent: () => void;
  isRunningAgent: boolean;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  schedule,
  onScheduleUpdated,
  onRunAgent,
  isRunningAgent,
}) => {
  const [form, setForm] = useState<AutomationScheduleConfig>(schedule);
  const [isSaving, setIsSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSave = async () => {
    setIsSaving(true);
    setSuccessMsg(null);
    try {
      const res = await updateSchedule(form);
      onScheduleUpdated(res.schedule);
      setSuccessMsg('Scheduler configuration updated successfully.');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const toggleActive = async () => {
    const updated = { ...form, isActive: !form.isActive };
    setForm(updated);
    try {
      const res = await updateSchedule(updated);
      onScheduleUpdated(res.schedule);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-neutral-100">Automation Scheduler & Background Runner</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Configure automated interval execution, rate-limits, auto-submission limits, and inspect execution audit logs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleActive}
            className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded transition-colors ${
              form.isActive
                ? 'bg-amber-400/10 text-amber-400 border border-amber-400/20 hover:bg-amber-400/20'
                : 'bg-emerald-400 text-neutral-950 hover:bg-emerald-300'
            }`}
          >
            {form.isActive ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause Scheduled Agent</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Activate Agent</span>
              </>
            )}
          </button>

          <button
            onClick={onRunAgent}
            disabled={isRunningAgent}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-100 rounded transition-colors disabled:opacity-50"
          >
            {isRunningAgent ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Running...</span>
              </>
            ) : (
              <>
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Run Cycle Now</span>
              </>
            )}
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 rounded bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Schedule Settings Box */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
        <h2 className="text-sm font-semibold text-neutral-200">Execution Cadence & Controls</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Frequency */}
          <div>
            <label className="text-neutral-400 block mb-1">Search & Run Frequency</label>
            <select
              value={form.frequency}
              onChange={(e) => setForm({ ...form, frequency: e.target.value as any })}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-200"
            >
              <option value="every_hour">Every 1 Hour (High Activity)</option>
              <option value="every_6_hours">Every 6 Hours</option>
              <option value="every_12_hours">Twice Daily (Every 12 Hours - Recommended)</option>
              <option value="once_daily">Once Daily (Standard)</option>
            </select>
          </div>

          {/* Max applications per run */}
          <div>
            <label className="text-neutral-400 block mb-1">Max Applications Per Run</label>
            <input
              type="number"
              min="1"
              max="20"
              value={form.maxApplicationsPerRun}
              onChange={(e) => setForm({ ...form, maxApplicationsPerRun: Number(e.target.value) })}
              className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-100 font-mono"
            />
            <span className="text-[10px] text-neutral-400 mt-0.5 block">
              Safe rate-limiting to prevent spam
            </span>
          </div>

          {/* Auto-Submit switch */}
          <div>
            <label className="text-neutral-400 block mb-1">Auto-Submit Permitted Channels</label>
            <div className="pt-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.autoSubmitEnabled}
                  onChange={(e) => setForm({ ...form, autoSubmitEnabled: e.target.checked })}
                  className="w-4 h-4 accent-emerald-500 rounded"
                />
                <span className="text-neutral-300">
                  {form.autoSubmitEnabled ? 'Enabled for permitted feeds' : 'Draft / Prepare only'}
                </span>
              </label>
            </div>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Saving...' : 'Save Schedule Settings'}</span>
          </button>
        </div>
      </div>

      {/* GitHub Actions 24/7 Free Execution Note */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2 text-xs">
        <div className="flex items-center gap-2 text-neutral-200 font-semibold">
          <Github className="w-4 h-4 text-emerald-400" />
          <span>Continuous Background Execution via GitHub Actions (Free ₹0)</span>
        </div>
        <p className="text-neutral-400 leading-relaxed">
          Browser tabs sleep when closed. For uninterrupted scheduled searches, this project includes a complete GitHub Actions workflow (<code className="text-neutral-300 font-mono">.github/workflows/job_agent_cron.yml</code>) and Python CLI (<code className="text-neutral-300 font-mono">backend/agent_runner.py</code>). Simply push to your repository <strong className="text-neutral-200">free-ai-job</strong> to execute twice daily for free.
        </p>
      </div>

      {/* Run History Audit Logs */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3 text-xs">
        <h2 className="text-sm font-semibold text-neutral-200">Automation Run History & Audit Log</h2>

        {form.runHistory.length === 0 ? (
          <div className="text-neutral-400 py-4 text-center">
            No scheduled runs recorded yet. Click &quot;Run Cycle Now&quot; to test your first cycle.
          </div>
        ) : (
          <div className="divide-y divide-neutral-800/80">
            {form.runHistory.map((item) => (
              <div key={item.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 text-neutral-300 font-medium">
                    <span className="font-mono text-neutral-400">
                      {new Date(item.timestamp).toLocaleString()}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="text-emerald-400">{item.status.toUpperCase()}</span>
                  </div>
                  <p className="text-neutral-400 mt-1">{item.notes}</p>
                </div>

                <div className="flex items-center gap-3 font-mono text-[11px] text-neutral-400 shrink-0">
                  <span>+{item.jobsDiscovered} Discovered</span>
                  <span>+{item.applicationsSubmitted} Submitted</span>
                  <span>+{item.manualActionRequired} Manual</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
