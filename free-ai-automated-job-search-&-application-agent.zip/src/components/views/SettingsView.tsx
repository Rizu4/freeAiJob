import React, { useState } from 'react';
import {
  Settings,
  Github,
  Key,
  ShieldCheck,
  Terminal,
  CheckCircle2,
  ExternalLink,
  BookOpen,
} from 'lucide-react';

interface SettingsViewProps {
  hasGeminiKey: boolean;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ hasGeminiKey }) => {
  const [activeTab, setActiveTab] = useState<'deployment' | 'github' | 'checklist'>('deployment');

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-lg font-bold text-neutral-100">System Settings & Deployment Architecture</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Complete guide to exporting this code, connecting to your repository <strong className="text-neutral-200">free-ai-job</strong>, and configuring scheduled automation for ₹0.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-lg w-fit text-xs">
        <button
          onClick={() => setActiveTab('deployment')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'deployment' ? 'bg-neutral-800 text-neutral-100' : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Free Hosting Architecture
        </button>
        <button
          onClick={() => setActiveTab('github')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'github' ? 'bg-neutral-800 text-neutral-100' : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          GitHub Setup (free-ai-job)
        </button>
        <button
          onClick={() => setActiveTab('checklist')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'checklist' ? 'bg-neutral-800 text-neutral-100' : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Testing Checklist & Truthfulness Invariants
        </button>
      </div>

      {/* Tab 1: Deployment & Hosting */}
      {activeTab === 'deployment' && (
        <div className="space-y-4 text-xs">
          <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3">
            <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Free Architecture Overview (₹0 Cost Model)</span>
            </h2>
            <p className="text-neutral-300 leading-relaxed">
              This application is engineered from the ground up to operate with zero paid API subscriptions and zero recurring hosting fees:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
              <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="font-semibold text-neutral-200">1. Full-Stack Web App</div>
                <div className="text-[11px] text-neutral-400 leading-relaxed">
                  React + TypeScript + Vite + Express + SQLite/JSON. Runs locally via <code className="text-emerald-400">npm run dev</code> or deployed to any free Node host or container.
                </div>
              </div>

              <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="font-semibold text-neutral-200">2. Autonomous Background Runner</div>
                <div className="text-[11px] text-neutral-400 leading-relaxed">
                  GitHub Actions scheduled workflow (<code className="text-emerald-400">job_agent_cron.yml</code>) executes the Python agent runner twice daily using GitHub&apos;s generous free runner quota.
                </div>
              </div>

              <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="font-semibold text-neutral-200">3. AI & Natural Language</div>
                <div className="text-[11px] text-neutral-400 leading-relaxed">
                  Uses Google Gemini 3.8 Flash via the free API tier. Even without an API key, the built-in deterministic regex & NLP engine guarantees 100% functionality.
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-3">
            <h2 className="text-sm font-semibold text-neutral-200">AI Model Status</h2>
            <div className="flex items-center gap-3">
              <div
                className={`w-3 h-3 rounded-full ${
                  hasGeminiKey ? 'bg-emerald-400' : 'bg-neutral-600'
                }`}
              />
              <span className="text-neutral-200 font-medium">
                {hasGeminiKey
                  ? 'Gemini 3.8 Flash Active (via Google AI Studio)'
                  : 'Rule-Based Deterministic Fallback Active (₹0 Free)'}
              </span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              When running in Google AI Studio, your API key is injected server-side automatically. When running on your own machine or on GitHub Actions, you can configure your free GEMINI_API_KEY as an environment secret.
            </p>
          </div>
        </div>
      )}

      {/* Tab 2: GitHub Setup */}
      {activeTab === 'github' && (
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
          <div className="flex items-center gap-2 text-neutral-200 font-semibold text-sm">
            <Github className="w-4 h-4 text-emerald-400" />
            <span>Instructions to Push to Repository: free-ai-job</span>
          </div>

          <p className="text-neutral-300 leading-relaxed">
            Follow these exact terminal commands to push the entire working codebase to your GitHub repository:
          </p>

          <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 font-mono text-[11px] text-neutral-200 space-y-2 overflow-x-auto">
            <div><span className="text-neutral-500"># 1. Initialize git (if not already initialized)</span></div>
            <div>git init</div>
            <div><span className="text-neutral-500"># 2. Add your existing remote repository</span></div>
            <div>git remote add origin https://github.com/&lt;YOUR_GITHUB_USERNAME&gt;/free-ai-job.git</div>
            <div><span className="text-neutral-500"># 3. Stage all files</span></div>
            <div>git add .</div>
            <div><span className="text-neutral-500"># 4. Commit</span></div>
            <div>git commit -m &quot;feat: complete AI automated job search & application agent&quot;</div>
            <div><span className="text-neutral-500"># 5. Push to main branch</span></div>
            <div>git branch -M main</div>
            <div>git push -u origin main</div>
          </div>

          <div className="pt-2 space-y-2">
            <h3 className="font-semibold text-neutral-200">Configuring GitHub Actions Secrets:</h3>
            <ol className="list-decimal list-inside space-y-1 text-neutral-400">
              <li>Open your repository on GitHub: <strong className="text-neutral-300">free-ai-job</strong></li>
              <li>Navigate to <strong className="text-neutral-300">Settings → Secrets and variables → Actions</strong></li>
              <li>Click <strong className="text-neutral-300">New repository secret</strong></li>
              <li>Set Name: <code className="text-emerald-400 font-mono">GEMINI_API_KEY</code></li>
              <li>Set Value: Your free Gemini API key from Google AI Studio</li>
              <li>Navigate to <strong className="text-neutral-300">Actions tab</strong> on your repo and enable scheduled runs!</li>
            </ol>
          </div>
        </div>
      )}

      {/* Tab 3: Testing Checklist & Truthfulness */}
      {activeTab === 'checklist' && (
        <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
          <h2 className="text-sm font-semibold text-neutral-200">Verification & Operational Checklist</h2>

          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded bg-neutral-900/60 border border-neutral-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-medium text-neutral-200">1. CV Parsing Verification</div>
                <p className="text-neutral-400 mt-0.5 text-[11px]">
                  Upload a PDF/DOCX or paste text. Verify that your actual education, past employers, and skills match what was extracted. Zero false credentials are ever added.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded bg-neutral-900/60 border border-neutral-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-medium text-neutral-200">2. Public Job Feeds & Sponsorship Evidence</div>
                <p className="text-neutral-400 mt-0.5 text-[11px]">
                  Click &quot;Query Public Sources Now&quot; in International Search. The agent contacts Arbeitnow, Jobicy, and Remotive public APIs, filtering for genuine visa sponsorship and work permit categories.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded bg-neutral-900/60 border border-neutral-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-medium text-neutral-200">3. Transparent 0-100 Scoring Formula</div>
                <p className="text-neutral-400 mt-0.5 text-[11px]">
                  Click &quot;Inspect&quot; on any job card. Inspect the exact points awarded for title match, skills overlap, location, visa sponsorship, and experience.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded bg-neutral-900/60 border border-neutral-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-medium text-neutral-200">4. Manual Action vs Auto-Submit Invariants</div>
                <p className="text-neutral-400 mt-0.5 text-[11px]">
                  The system never fakes automated submissions. If a job portal requires Workday/Greenhouse account login or CAPTCHA, it is placed in the Manual Action queue with pre-filled 1-click copyable candidate details.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
