import React, { useState } from 'react';
import { Bookmark, ExternalLink, ShieldCheck, Eye, Trash2, CheckCircle2 } from 'lucide-react';
import type { JobListing, CandidateProfile } from '../../types.ts';
import { prepareApplication } from '../../utils/api.ts';
import { JobDetailModal } from '../JobDetailModal.tsx';

interface SavedJobsViewProps {
  jobs: JobListing[];
  savedJobIds: Set<string>;
  profile: CandidateProfile;
  onToggleSaveJob: (jobId: string) => void;
  onNavigateToCoverLetter: (job: JobListing) => void;
  onApplicationCreated: () => void;
}

export const SavedJobsView: React.FC<SavedJobsViewProps> = ({
  jobs,
  savedJobIds,
  profile,
  onToggleSaveJob,
  onNavigateToCoverLetter,
  onApplicationCreated,
}) => {
  const [inspectJob, setInspectJob] = useState<JobListing | null>(null);
  const [isPreparingId, setIsPreparingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const bookmarkedJobs = jobs.filter((j) => savedJobIds.has(j.id));

  const handlePrepare = async (jobId: string) => {
    setIsPreparingId(jobId);
    try {
      await prepareApplication(jobId);
      onApplicationCreated();
      setFeedback('Application package prepared!');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsPreparingId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-lg font-bold text-neutral-100">Saved Vacancies</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Your bookmarked international job listings for priority review, custom cover letters, or manual tracking.
        </p>
      </div>

      {feedback && (
        <div className="p-3 rounded bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {bookmarkedJobs.length === 0 ? (
        <div className="p-12 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
          <Bookmark className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
          <h2 className="text-sm font-semibold text-neutral-200">No saved jobs yet</h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
            Click the bookmark icon on any job card in International Job Search or Matched Jobs to save it here.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {bookmarkedJobs.map((job) => (
            <div
              key={job.id}
              className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 transition-colors"
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-base font-bold text-neutral-100">{job.title}</h2>
                      <div className="flex items-center gap-2 text-xs text-neutral-400 mt-1">
                        <span className="text-neutral-200 font-medium">{job.company}</span>
                        <span aria-hidden="true">·</span>
                        <span>{job.location}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-neutral-300 font-medium">{job.country}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => onToggleSaveJob(job.id)}
                      className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-neutral-900 rounded transition-colors"
                      title="Remove Bookmark"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-xs text-neutral-400 mt-2 line-clamp-2">
                    {job.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0 pt-2 md:pt-0">
                  <button
                    onClick={() => setInspectJob(job)}
                    className="px-2.5 py-1.5 text-xs text-neutral-300 hover:text-neutral-100 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded transition-colors"
                  >
                    View Details
                  </button>
                  <button
                    onClick={() => handlePrepare(job.id)}
                    disabled={isPreparingId === job.id}
                    className="px-3.5 py-1.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
                  >
                    {isPreparingId === job.id ? 'Preparing...' : 'Prepare Application'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <JobDetailModal
        job={inspectJob}
        profile={profile}
        isOpen={Boolean(inspectJob)}
        onClose={() => setInspectJob(null)}
        onPrepareApplication={handlePrepare}
        onGenerateCoverLetter={(job) => {
          setInspectJob(null);
          onNavigateToCoverLetter(job);
        }}
      />
    </div>
  );
};
