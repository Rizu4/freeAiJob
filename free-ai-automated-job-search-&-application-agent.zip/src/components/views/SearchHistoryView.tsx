import React from 'react';
import { History, Globe2, CheckCircle2, Clock } from 'lucide-react';
import type { SearchHistoryRecord } from '../../types.ts';

interface SearchHistoryViewProps {
  history: SearchHistoryRecord[];
  onTriggerSearch: (query: string) => void;
}

export const SearchHistoryView: React.FC<SearchHistoryViewProps> = ({
  history,
  onTriggerSearch,
}) => {
  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-lg font-bold text-neutral-100">Job Search History & Audit Trail</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Historical log of automated and manual job search queries, sources fetched, and profile matches recorded.
        </p>
      </div>

      {history.length === 0 ? (
        <div className="p-12 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
          <History className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
          <h2 className="text-sm font-semibold text-neutral-200">No search logs recorded</h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
            Search queries and discoveries will automatically be recorded here after each discovery cycle.
          </p>
        </div>
      ) : (
        <div className="rounded-lg bg-neutral-950 border border-neutral-800 overflow-hidden text-xs">
          <table className="w-full text-left divide-y divide-neutral-800">
            <thead className="bg-neutral-900/60 text-neutral-400 uppercase text-[10px] tracking-wider font-mono">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-4 py-3">Keywords / Categories</th>
                <th className="px-4 py-3">Destinations</th>
                <th className="px-4 py-3">Sources</th>
                <th className="px-4 py-3 text-right">Discovered</th>
                <th className="px-4 py-3 text-right">Matched</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/80">
              {history.map((record) => (
                <tr key={record.id} className="hover:bg-neutral-900/40 transition-colors">
                  <td className="px-4 py-3 font-mono text-neutral-400 whitespace-nowrap">
                    {new Date(record.timestamp).toLocaleString([], {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </td>
                  <td className="px-4 py-3 font-medium text-neutral-200">
                    {record.query}
                  </td>
                  <td className="px-4 py-3 text-neutral-400 truncate max-w-xs">
                    {record.country}
                  </td>
                  <td className="px-4 py-3 text-neutral-400">
                    {record.source}
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-neutral-300">
                    {record.resultsCount}
                  </td>
                  <td className="px-4 py-3 text-right font-mono tabular-nums text-emerald-400 font-semibold">
                    {record.matchedCount}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
