import React, { useState } from 'react';
import {
  ShieldCheck,
  Download,
  Trash2,
  Lock,
  EyeOff,
  Server,
  AlertTriangle,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import { resetAllData } from '../../utils/api.ts';

interface PrivacyDataViewProps {
  onDataReset: () => void;
}

export const PrivacyDataView: React.FC<PrivacyDataViewProps> = ({ onDataReset }) => {
  const [isResetting, setIsResetting] = useState(false);
  const [confirmWipe, setConfirmWipe] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleExport = () => {
    window.location.href = '/api/data/export';
  };

  const handleReset = async () => {
    setIsResetting(true);
    try {
      await resetAllData();
      setSuccessMsg('All candidate details, uploaded CVs, and application records have been permanently wiped.');
      setConfirmWipe(false);
      onDataReset();
      setTimeout(() => setSuccessMsg(null), 5000);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-lg font-bold text-neutral-100">Privacy, Security & Data Management</h1>
        <p className="text-xs text-neutral-400 mt-1">
          Full data sovereignty. Your CV, applications, and search history remain strictly on your own device and private database.
        </p>
      </div>

      {successMsg && (
        <div className="p-3 rounded bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Privacy Guarantees */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
        <h2 className="text-sm font-semibold text-neutral-200 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Privacy & Security Commitments</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-neutral-200">
              <Lock className="w-3.5 h-3.5 text-blue-400" />
              <span>Zero Password Storage</span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              We never store your passwords for Workday, LinkedIn, Indeed, or employer portals. For sites requiring logins, pre-filled application packages are prepared for you to safely submit manually.
            </p>
          </div>

          <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-neutral-200">
              <Server className="w-3.5 h-3.5 text-emerald-400" />
              <span>Local File & SQLite Persistence</span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              All parsed profiles and application records are saved in your local <code className="text-neutral-300">data/db.json</code> or <code className="text-neutral-300">backend/job_agent.db</code>. No unauthorized cloud telemetry is recorded.
            </p>
          </div>

          <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-neutral-200">
              <EyeOff className="w-3.5 h-3.5 text-purple-400" />
              <span>Zero Unsolicited Data Broadcast</span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              Your contact details are only dispatched when you or the automated runner specifically prepares or submits an application to a verified employer vacancy.
            </p>
          </div>

          <div className="p-3.5 rounded bg-neutral-900 border border-neutral-800 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-neutral-200">
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>Truthfulness Invariant</span>
            </div>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              The agent is hardcoded to never invent degrees, past employers, or fake work authorizations. Every application submitted is 100% verified and truthful.
            </p>
          </div>
        </div>
      </div>

      {/* Data Export & Management */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 space-y-4 text-xs">
        <h2 className="text-sm font-semibold text-neutral-200">Export & Backup</h2>
        <p className="text-neutral-400 leading-relaxed">
          Download a complete portable JSON export of your candidate profile, saved preferences, discovered jobs, and application tracking history.
        </p>

        <div>
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-neutral-100 border border-neutral-700 rounded transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Complete Database (JSON)</span>
          </button>
        </div>
      </div>

      {/* Danger Zone: Wipe / Reset */}
      <div className="p-5 rounded-lg bg-neutral-950 border border-rose-900/40 space-y-3 text-xs">
        <div className="flex items-center gap-2 text-rose-400 font-semibold text-sm">
          <AlertTriangle className="w-4 h-4" />
          <span>Danger Zone: Permanent Data Wipe</span>
        </div>
        <p className="text-neutral-400 leading-relaxed">
          If you want to clear all your stored CV text, personal credentials, and application tracking history from this machine, you can reset the database. This action cannot be undone.
        </p>

        {!confirmWipe ? (
          <button
            onClick={() => setConfirmWipe(true)}
            className="px-3.5 py-1.5 text-xs font-semibold text-rose-400 bg-rose-950/30 border border-rose-800/40 hover:bg-rose-950/50 rounded transition-colors"
          >
            Reset & Wipe Candidate Data
          </button>
        ) : (
          <div className="p-3 rounded bg-rose-950/50 border border-rose-800 space-y-2">
            <p className="text-rose-200 font-medium">Are you sure you want to permanently erase all records?</p>
            <div className="flex items-center gap-2">
              <button
                onClick={handleReset}
                disabled={isResetting}
                className="px-3.5 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded transition-colors disabled:opacity-50"
              >
                {isResetting ? 'Wiping...' : 'Yes, Permanently Wipe All Records'}
              </button>
              <button
                onClick={() => setConfirmWipe(false)}
                className="px-3.5 py-1.5 text-xs font-medium bg-neutral-800 text-neutral-300 hover:bg-neutral-700 rounded transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
