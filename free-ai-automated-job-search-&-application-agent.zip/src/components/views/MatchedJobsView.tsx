import React, { useState } from 'react';
import {
  CheckCircle2,
  Bookmark,
  ExternalLink,
  ShieldCheck,
  Eye,
  FileCheck,
  Sliders,
  AlertTriangle,
} from 'lucide-react';
import type { JobListing, CandidateProfile, JobPreferences } from '../../types.ts';
import { prepareApplication } from '../../utils/api.ts';
import { JobDetailModal } from '../JobDetailModal.tsx';

interface MatchedJobsViewProps {
  jobs: JobListing[];
  profile: CandidateProfile;
  preferences: JobPreferences;
  savedJobIds: Set<string>;
  onToggleSaveJob: (jobId: string) => void;
  onNavigateToPreferences: () => void;
  onNavigateToCoverLetter: (job: JobListing) => void;
  onApplicationCreated: () => void;
}

export const MatchedJobsView: React.FC<MatchedJobsViewProps> = ({
  jobs,
  profile,
  preferences,
  savedJobIds,
  onToggleSaveJob,
  onNavigateToPreferences,
  onNavigateToCoverLetter,
  onApplicationCreated,
}) => {
  const [inspectJob, setInspectJob] = useState<JobListing | null>(null);
  const [isPreparingId, setIsPreparingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const matchedJobs = jobs
    .filter((j) => j.matchScore >= preferences.minimumMatchScore)
    .sort((a, b) => b.matchScore - a.matchScore);

  const handlePrepareApp = async (jobId: string) => {
    setIsPreparingId(jobId);
    try {
      await prepareApplication(jobId);
      onApplicationCreated();
      setFeedback('Application successfully prepared and added to the tracking queue.');
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: any) {
      console.error('Failed to prepare:', err);
    } finally {
      setIsPreparingId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-neutral-100">Profile-Matched Opportunities</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Vacancies evaluated with a match score ≥ {preferences.minimumMatchScore}/100 based on your skills, experience, and destination preferences.
          </p>
        </div>

        <button
          onClick={onNavigateToPreferences}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-300 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded transition-colors whitespace-nowrap shrink-0"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Adjust Threshold ({preferences.minimumMatchScore}%)</span>
        </button>
      </div>

      {feedback && (
        <div className="p-3 rounded bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {matchedJobs.length === 0 ? (
        <div className="p-12 rounded-lg bg-neutral-950 border border-neutral-800 text-center">
          <CheckCircle2 className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
          <h2 className="text-sm font-semibold text-neutral-200">No jobs exceed current threshold</h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
            Currently no discovered jobs meet your minimum score of {preferences.minimumMatchScore}. You can lower your threshold in Preferences or trigger a new search.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {matchedJobs.map((job) => {
            const isSaved = savedJobIds.has(job.id);
            const isAuto = job.applicationMethod === 'auto_permitted';

            return (
              <div
                key={job.id}
                className="p-5 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="text-base font-bold text-neutral-100 hover:text-emerald-300 transition-colors">
                          {job.title}
                        </h2>
                        {/* Unboxed Metadata with · separator */}
                        <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 mt-1">
                          <span className="text-neutral-200 font-medium">{job.company}</span>
                          <span aria-hidden="true">·</span>
                          <span>{job.location}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-neutral-300 font-medium">{job.country}</span>
                          <span aria-hidden="true">·</span>
                          <span>{job.jobType}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => onToggleSaveJob(job.id)}
                          title={isSaved ? 'Remove from Saved' : 'Save Job'}
                          className={`p-1.5 rounded transition-colors ${
                            isSaved
                              ? 'text-amber-400 bg-amber-950/40 border border-amber-800/40'
                              : 'text-neutral-500 hover:text-neutral-300 hover:bg-neutral-900'
                          }`}
                        >
                          <Bookmark className="w-4 h-4 fill-current" />
                        </button>
                      </div>
                    </div>

                    {/* Sponsorship Quote Strip */}
                    <div className="mt-3 p-2.5 rounded bg-neutral-900/60 border border-neutral-800 text-xs flex items-start gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-neutral-300 font-medium">Sponsorship Verification: </span>
                        <span className="text-neutral-400">
                          &ldquo;{job.visaSponsorshipEvidence?.evidenceSnippet || 'Standard permit'}&rdquo;
                        </span>
                      </div>
                    </div>

                    {/* Match Score Explanation Tags */}
                    {job.matchBreakdown?.explanation && (
                      <div className="mt-2.5 flex flex-wrap gap-2 text-[11px] text-neutral-400">
                        {job.matchBreakdown.explanation.slice(0, 3).map((exp, idx) => (
                          <span key={idx} className="bg-neutral-900/80 px-2 py-0.5 rounded border border-neutral-800 text-neutral-300">
                            {exp}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Right Score Block & Actions */}
                  <div className="flex flex-row md:flex-col items-center md:items-end justify-between gap-3 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-neutral-800">
                    <div className="text-left md:text-right">
                      <div className="font-mono text-xl font-bold tabular-nums text-emerald-400">
                        {job.matchScore}/100
                      </div>
                      <div className="text-[10px] text-neutral-400">Match Confidence</div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setInspectJob(job)}
                        className="px-2.5 py-1.5 text-xs text-neutral-300 hover:text-neutral-100 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded transition-colors"
                      >
                        Breakdown
                      </button>

                      <button
                        onClick={() => handlePrepareApp(job.id)}
                        disabled={isPreparingId === job.id}
                        className="px-3.5 py-1.5 text-xs font-semibold bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded transition-colors disabled:opacity-50"
                      >
                        {isPreparingId === job.id ? 'Preparing...' : 'Prepare Application'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Inspect Modal */}
      <JobDetailModal
        job={inspectJob}
        profile={profile}
        isOpen={Boolean(inspectJob)}
        onClose={() => setInspectJob(null)}
        onPrepareApplication={handlePrepareApp}
        onGenerateCoverLetter={(job) => {
          setInspectJob(null);
          onNavigateToCoverLetter(job);
        }}
        isPreparing={Boolean(isPreparingId)}
      />
    </div>
  );
};
