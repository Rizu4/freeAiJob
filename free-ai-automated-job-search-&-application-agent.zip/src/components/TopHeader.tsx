import React from 'react';
import { Play, Loader2, Sparkles, RefreshCw } from 'lucide-react';
import type { NavigationTab } from './Sidebar.tsx';

interface TopHeaderProps {
  currentTab: NavigationTab;
  isRunningAgent: boolean;
  onRunAgent: () => void;
  onRefresh: () => void;
  isRefreshing?: boolean;
}

const tabTitles: Record<NavigationTab, { title: string; breadcrumb: string }> = {
  overview: { title: 'Agent Overview', breadcrumb: 'Workspace / Overview' },
  'upload-cv': { title: 'Upload & Parse CV', breadcrumb: 'Candidate / Upload CV' },
  profile: { title: 'Candidate Profile', breadcrumb: 'Candidate / Verified Profile' },
  preferences: { title: 'Job Preferences', breadcrumb: 'Matching Rules / Preferences' },
  search: { title: 'International Job Search', breadcrumb: 'Discovery / Worldwide Jobs' },
  matched: { title: 'Matched Jobs', breadcrumb: 'Discovery / High-Score Matches' },
  'auto-applications': { title: 'Automatic Applications', breadcrumb: 'Applications / Auto Submission' },
  'in-progress': { title: 'Applications in Progress', breadcrumb: 'Applications / Prepared Queue' },
  submitted: { title: 'Submitted Applications', breadcrumb: 'Applications / Verified Submissions' },
  failed: { title: 'Failed Applications', breadcrumb: 'Applications / Error Queue' },
  'manual-action': { title: 'Manual Action Required', breadcrumb: 'Applications / Action Required' },
  saved: { title: 'Saved Jobs', breadcrumb: 'Discovery / Bookmarks' },
  'cover-letters': { title: 'Cover Letters', breadcrumb: 'Documents / Cover Letter Generator' },
  history: { title: 'Search History', breadcrumb: 'Auditing / Search History' },
  schedule: { title: 'Automation Schedule', breadcrumb: 'Scheduler / Runner Settings' },
  settings: { title: 'System Settings', breadcrumb: 'Configuration / Preferences' },
  privacy: { title: 'Privacy and Data Management', breadcrumb: 'Security / Storage & Privacy' },
};

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentTab,
  isRunningAgent,
  onRunAgent,
  onRefresh,
  isRefreshing,
}) => {
  const currentMeta = tabTitles[currentTab] || { title: 'Job Agent', breadcrumb: 'Workspace' };

  return (
    <header className="h-14 bg-neutral-950/80 backdrop-blur border-b border-neutral-800 px-6 flex items-center justify-between gap-8 sticky top-0 z-30">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-2 whitespace-nowrap shrink-0">
        <span className="text-sm font-semibold text-neutral-100">JobAgent Automation</span>
      </div>

      {/* Zone 2: Concise breadcrumb trail */}
      <div className="hidden md:flex items-center gap-2 text-xs text-neutral-400 whitespace-nowrap shrink-0 truncate">
        <span>{currentMeta.breadcrumb}</span>
        <span aria-hidden="true">·</span>
        <span className="text-neutral-300 font-medium">{currentMeta.title}</span>
      </div>

      {/* Zone 3: 1 Primary Action (with secondary refresh icon) */}
      <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
        <button
          onClick={onRefresh}
          title="Refresh Data"
          disabled={isRefreshing}
          className="p-2 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900 rounded-md transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
        </button>

        <button
          onClick={onRunAgent}
          disabled={isRunningAgent}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 rounded-md transition-colors shadow-sm disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
        >
          {isRunningAgent ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Processing Jobs...</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run Agent Cycle</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
