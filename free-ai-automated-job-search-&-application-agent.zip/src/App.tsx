/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import type {
  CandidateProfile,
  JobPreferences,
  JobListing,
  ApplicationRecord,
  DashboardStats,
  AutomationScheduleConfig,
  SearchHistoryRecord,
} from './types.ts';
import {
  fetchProfile,
  fetchPreferences,
  fetchJobs,
  fetchApplications,
  fetchDashboardStats,
  fetchSchedule,
  runAgentCycle,
  fetchStatus,
} from './utils/api.ts';
import { Sidebar, type NavigationTab } from './components/Sidebar.tsx';
import { TopHeader } from './components/TopHeader.tsx';
import { OverviewView } from './components/views/OverviewView.tsx';
import { UploadCvView } from './components/views/UploadCvView.tsx';
import { CandidateProfileView } from './components/views/CandidateProfileView.tsx';
import { JobPreferencesView } from './components/views/JobPreferencesView.tsx';
import { JobSearchView } from './components/views/JobSearchView.tsx';
import { MatchedJobsView } from './components/views/MatchedJobsView.tsx';
import { ApplicationsQueueView } from './components/views/ApplicationsQueueView.tsx';
import { SavedJobsView } from './components/views/SavedJobsView.tsx';
import { CoverLettersView } from './components/views/CoverLettersView.tsx';
import { SearchHistoryView } from './components/views/SearchHistoryView.tsx';
import { ScheduleView } from './components/views/ScheduleView.tsx';
import { SettingsView } from './components/views/SettingsView.tsx';
import { PrivacyDataView } from './components/views/PrivacyDataView.tsx';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('overview');
  const [profile, setProfile] = useState<CandidateProfile | null>(null);
  const [preferences, setPreferences] = useState<JobPreferences | null>(null);
  const [jobs, setJobs] = useState<JobListing[]>([]);
  const [applications, setApplications] = useState<ApplicationRecord[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [schedule, setSchedule] = useState<AutomationScheduleConfig | null>(null);
  const [hasGeminiKey, setHasGeminiKey] = useState<boolean>(false);

  // Saved Jobs tracking
  const [savedJobIds, setSavedJobIds] = useState<Set<string>>(() => {
    try {
      const stored = localStorage.getItem('job_agent_saved_ids');
      return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch {
      return new Set();
    }
  });

  // Cover letter context
  const [coverLetterJob, setCoverLetterJob] = useState<JobListing | null>(null);

  // Loading states
  const [isLoadingInitial, setIsLoadingInitial] = useState(true);
  const [isRunningAgent, setIsRunningAgent] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Global Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const loadAllData = async () => {
    setIsRefreshing(true);
    try {
      const [
        profileData,
        prefsData,
        jobsData,
        appsData,
        statsData,
        schedData,
        statusData,
      ] = await Promise.all([
        fetchProfile(),
        fetchPreferences(),
        fetchJobs(),
        fetchApplications(),
        fetchDashboardStats(),
        fetchSchedule(),
        fetchStatus().catch(() => ({ hasGeminiKey: false })),
      ]);

      setProfile(profileData);
      setPreferences(prefsData);
      setJobs(jobsData.jobs || []);
      setApplications(appsData.applications || []);
      setStats(statsData);
      setSchedule(schedData);
      setHasGeminiKey(Boolean((statusData as any)?.hasGeminiKey));
    } catch (err) {
      console.error('Error loading initial data:', err);
    } finally {
      setIsRefreshing(false);
      setIsLoadingInitial(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Save jobs in local storage
  const handleToggleSaveJob = (jobId: string) => {
    setSavedJobIds((prev) => {
      const updated = new Set(prev);
      if (updated.has(jobId)) {
        updated.delete(jobId);
        showToast('Removed from saved jobs.');
      } else {
        updated.add(jobId);
        showToast('Saved to your bookmarks.');
      }
      try {
        localStorage.setItem('job_agent_saved_ids', JSON.stringify(Array.from(updated)));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  // Run Agent Cycle
  const handleRunAgent = async () => {
    setIsRunningAgent(true);
    try {
      const res = await runAgentCycle();
      showToast(
        `Agent cycle complete! Discovered ${res.summary.jobsDiscovered} jobs, prepared ${res.summary.applicationsPrepared}, submitted ${res.summary.applicationsSubmitted}.`
      );
      await loadAllData();
    } catch (err: any) {
      showToast(`Agent error: ${err.message || 'Cycle failed'}`);
    } finally {
      setIsRunningAgent(false);
    }
  };

  const handleNavigateToCoverLetter = (job: JobListing) => {
    setCoverLetterJob(job);
    setCurrentTab('cover-letters');
  };

  if (isLoadingInitial || !profile || !preferences || !schedule) {
    return (
      <div className="min-h-screen bg-neutral-950 text-neutral-100 flex items-center justify-center font-sans">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 rounded-full border-2 border-emerald-400 border-t-transparent animate-spin mx-auto" />
          <div className="text-xs text-neutral-400 font-mono">
            Initializing Free AI Job Automation Agent...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex font-sans selection:bg-emerald-500/20 selection:text-emerald-300 antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        stats={stats}
        savedJobsCount={savedJobIds.size}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        {/* Top Header */}
        <TopHeader
          currentTab={currentTab}
          isRunningAgent={isRunningAgent}
          onRunAgent={handleRunAgent}
          onRefresh={loadAllData}
          isRefreshing={isRefreshing}
        />

        {/* Global Toast */}
        {toastMessage && (
          <div className="fixed bottom-5 right-5 z-50 bg-neutral-900 border border-neutral-700 text-neutral-100 px-4 py-2.5 rounded-lg shadow-xl text-xs flex items-center gap-2 max-w-md animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            <span className="truncate">{toastMessage}</span>
          </div>
        )}

        {/* View Routing */}
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
          {currentTab === 'overview' && (
            <OverviewView
              stats={stats}
              profile={profile}
              jobs={jobs}
              applications={applications}
              onNavigate={setCurrentTab}
              onRunAgent={handleRunAgent}
              isRunningAgent={isRunningAgent}
            />
          )}

          {currentTab === 'upload-cv' && (
            <UploadCvView
              currentProfile={profile}
              onProfileUpdated={(updated) => {
                setProfile(updated);
                loadAllData();
                showToast('CV parsed and candidate profile verified!');
              }}
              onNavigateToProfile={() => setCurrentTab('profile')}
            />
          )}

          {currentTab === 'profile' && (
            <CandidateProfileView
              profile={profile}
              onProfileUpdated={(updated) => {
                setProfile(updated);
                loadAllData();
                showToast('Candidate profile updated.');
              }}
            />
          )}

          {currentTab === 'preferences' && (
            <JobPreferencesView
              preferences={preferences}
              onPreferencesUpdated={(updated) => {
                setPreferences(updated);
                loadAllData();
                showToast('Job targeting preferences saved.');
              }}
            />
          )}

          {currentTab === 'search' && (
            <JobSearchView
              jobs={jobs}
              profile={profile}
              preferences={preferences}
              savedJobIds={savedJobIds}
              onToggleSaveJob={handleToggleSaveJob}
              onRefreshJobs={loadAllData}
              onNavigateToCoverLetter={handleNavigateToCoverLetter}
              onApplicationCreated={() => {
                loadAllData();
                showToast('Application created in pipeline queue.');
              }}
            />
          )}

          {currentTab === 'matched' && (
            <MatchedJobsView
              jobs={jobs}
              profile={profile}
              preferences={preferences}
              savedJobIds={savedJobIds}
              onToggleSaveJob={handleToggleSaveJob}
              onNavigateToPreferences={() => setCurrentTab('preferences')}
              onNavigateToCoverLetter={handleNavigateToCoverLetter}
              onApplicationCreated={() => {
                loadAllData();
                showToast('Application created in pipeline queue.');
              }}
            />
          )}

          {currentTab === 'manual-action' && (
            <ApplicationsQueueView
              applications={applications}
              filterStatus="manual-only"
              title="Manual Action Required Queue"
              onRefresh={loadAllData}
            />
          )}

          {currentTab === 'auto-applications' && (
            <ApplicationsQueueView
              applications={applications}
              filterStatus="auto-only"
              title="Automatic Applications Engine"
              onRefresh={loadAllData}
            />
          )}

          {currentTab === 'in-progress' && (
            <ApplicationsQueueView
              applications={applications}
              filterStatus="in-progress"
              title="Applications in Progress (Prepared Queue)"
              onRefresh={loadAllData}
            />
          )}

          {currentTab === 'submitted' && (
            <ApplicationsQueueView
              applications={applications}
              filterStatus="submitted"
              title="Verified Submitted Applications"
              onRefresh={loadAllData}
            />
          )}

          {currentTab === 'failed' && (
            <ApplicationsQueueView
              applications={applications}
              filterStatus="failed"
              title="Failed Applications & Error Logs"
              onRefresh={loadAllData}
            />
          )}

          {currentTab === 'saved' && (
            <SavedJobsView
              jobs={jobs}
              savedJobIds={savedJobIds}
              profile={profile}
              onToggleSaveJob={handleToggleSaveJob}
              onNavigateToCoverLetter={handleNavigateToCoverLetter}
              onApplicationCreated={loadAllData}
            />
          )}

          {currentTab === 'cover-letters' && (
            <CoverLettersView
              profile={profile}
              jobs={jobs}
              preselectedJob={coverLetterJob}
            />
          )}

          {currentTab === 'history' && (
            <SearchHistoryView
              history={stats ? (schedule as any).searchHistory || [] : []}
              onTriggerSearch={(query) => {
                setCurrentTab('search');
              }}
            />
          )}

          {currentTab === 'schedule' && (
            <ScheduleView
              schedule={schedule}
              onScheduleUpdated={(updated) => {
                setSchedule(updated);
                loadAllData();
              }}
              onRunAgent={handleRunAgent}
              isRunningAgent={isRunningAgent}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView hasGeminiKey={hasGeminiKey} />
          )}

          {currentTab === 'privacy' && (
            <PrivacyDataView onDataReset={loadAllData} />
          )}
        </main>
      </div>
    </div>
  );
}
