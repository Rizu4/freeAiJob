import type {
  CandidateProfile,
  JobPreferences,
  JobListing,
  ApplicationRecord,
  CoverLetterRecord,
  AutomationScheduleConfig,
  DashboardStats,
  SearchHistoryRecord,
} from '../types.ts';

const API_BASE = '/api';

export async function fetchStatus(): Promise<{ status: string; hasGeminiKey: boolean }> {
  const res = await fetch(`${API_BASE}/status`);
  return res.json();
}

export async function fetchProfile(): Promise<CandidateProfile> {
  const res = await fetch(`${API_BASE}/profile`);
  return res.json();
}

export async function updateProfile(profile: Partial<CandidateProfile>): Promise<{ success: boolean; profile: CandidateProfile }> {
  const res = await fetch(`${API_BASE}/profile`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(profile),
  });
  return res.json();
}

export async function fetchPreferences(): Promise<JobPreferences> {
  const res = await fetch(`${API_BASE}/preferences`);
  return res.json();
}

export async function updatePreferences(preferences: Partial<JobPreferences>): Promise<{ success: boolean; preferences: JobPreferences }> {
  const res = await fetch(`${API_BASE}/preferences`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(preferences),
  });
  return res.json();
}

export async function parseCv(payload: { cvText?: string; fileName?: string; fileBase64?: string; mimeType?: string }): Promise<{ success: boolean; message: string; profile: CandidateProfile }> {
  const res = await fetch(`${API_BASE}/cv/parse`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to parse CV');
  }
  return res.json();
}

export async function fetchJobs(params?: { minScore?: number; country?: string; search?: string; hasSponsorship?: boolean }): Promise<{ total: number; jobs: JobListing[] }> {
  const q = new URLSearchParams();
  if (params?.minScore) q.set('minScore', String(params.minScore));
  if (params?.country) q.set('country', params.country);
  if (params?.search) q.set('search', params.search);
  if (params?.hasSponsorship) q.set('hasSponsorship', 'true');

  const res = await fetch(`${API_BASE}/jobs?${q.toString()}`);
  return res.json();
}

export async function triggerJobSearch(query?: string, countries?: string[]): Promise<{ success: boolean; newJobsDiscovered: number; totalJobs: number; matchedJobs: number }> {
  const res = await fetch(`${API_BASE}/jobs/search`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, countries }),
  });
  return res.json();
}

export async function fetchApplications(params?: { status?: string; mode?: string }): Promise<{ total: number; applications: ApplicationRecord[] }> {
  const q = new URLSearchParams();
  if (params?.status) q.set('status', params.status);
  if (params?.mode) q.set('mode', params.mode);

  const res = await fetch(`${API_BASE}/applications?${q.toString()}`);
  return res.json();
}

export async function updateApplication(id: string, updates: Partial<ApplicationRecord>): Promise<{ success: boolean; application: ApplicationRecord }> {
  const res = await fetch(`${API_BASE}/applications/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  return res.json();
}

export async function prepareApplication(jobId: string): Promise<{ success: boolean; application: ApplicationRecord; message?: string }> {
  const res = await fetch(`${API_BASE}/applications/prepare`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jobId }),
  });
  return res.json();
}

export async function submitApplication(applicationId: string): Promise<{ success: boolean; requiresManualAction?: boolean; reason?: string; confirmationRef?: string; application: ApplicationRecord }> {
  const res = await fetch(`${API_BASE}/applications/submit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ applicationId }),
  });
  return res.json();
}

export async function generateCoverLetter(payload: { jobId?: string; jobTitle: string; company: string; country: string; jobDescription?: string }): Promise<{ success: boolean; coverLetter: CoverLetterRecord }> {
  const res = await fetch(`${API_BASE}/cover-letter/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json();
}

export async function runAgentCycle(): Promise<{ success: boolean; summary: any; totalApplications: number }> {
  const res = await fetch(`${API_BASE}/agent/run-cycle`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });
  return res.json();
}

export async function fetchSchedule(): Promise<AutomationScheduleConfig> {
  const res = await fetch(`${API_BASE}/schedule`);
  return res.json();
}

export async function updateSchedule(config: Partial<AutomationScheduleConfig>): Promise<{ success: boolean; schedule: AutomationScheduleConfig }> {
  const res = await fetch(`${API_BASE}/schedule`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  return res.json();
}

export async function fetchDashboardStats(): Promise<DashboardStats> {
  const res = await fetch(`${API_BASE}/dashboard/stats`);
  return res.json();
}

export async function resetAllData(): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${API_BASE}/data/reset`, {
    method: 'POST',
  });
  return res.json();
}
