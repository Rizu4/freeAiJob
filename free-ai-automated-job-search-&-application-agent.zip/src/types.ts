/**
 * Data contracts and schema for Free AI Automated Job Search & Application Agent
 */

export interface EducationItem {
  id: string;
  degree: string;
  field: string;
  institution: string;
  year: string;
  country: string;
}

export interface ExperienceItem {
  id: string;
  title: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  highlights: string[];
}

export interface LanguageItem {
  id: string;
  language: string;
  proficiency: 'Native' | 'Fluent' | 'Professional' | 'Intermediate' | 'Basic';
}

export interface CandidateProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  currentCity: string;
  currentCountry: string;
  workAuthorization: string[];
  summary: string;
  education: EducationItem[];
  experience: ExperienceItem[];
  skills: string[];
  softwareTools: string[];
  certifications: string[];
  languages: LanguageItem[];
  preferredTitles: string[];
  preferredIndustries: string[];
  totalYearsExperience: number;
  cvFileName?: string;
  cvUploadedAt?: string;
  cvRawText?: string;
  updatedAt: string;
}

export interface JobPreferences {
  targetCountries: string[];
  targetRoles: string[];
  experienceLevels: ('Entry Level' | 'Junior' | 'Mid Level' | 'Senior' | 'All')[];
  minimumSalaryExpected: number;
  currency: string;
  willingToRelocate: boolean;
  requireVisaSponsorship: boolean;
  remoteAllowed: boolean;
  minimumMatchScore: number;
  excludedEmployers: string[];
  enabledSources: string[];
}

export interface MatchBreakdown {
  skillsScore: number;
  titleScore: number;
  experienceScore: number;
  countryScore: number;
  sponsorshipScore: number;
  languageScore: number;
  explanation: string[];
}

export interface VisaSponsorshipEvidence {
  hasSponsorship: boolean;
  evidenceSnippet: string;
  sourceType: 'explicit_listing' | 'verified_permit_category' | 'none';
}

export interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  country: string;
  isRemote: boolean;
  jobType: string;
  salaryText?: string;
  description: string;
  originalUrl: string;
  source: string;
  dateDiscovered: string;
  visaSponsorshipEvidence: VisaSponsorshipEvidence;
  matchScore: number;
  matchBreakdown: MatchBreakdown;
  applicationMethod: 'auto_permitted' | 'manual_required';
  manualActionReason?: string;
}

export type ApplicationStatus =
  | 'Discovered'
  | 'Matched'
  | 'Prepared'
  | 'Submitted'
  | 'Confirmation Pending'
  | 'Interview'
  | 'Rejected'
  | 'Withdrawn'
  | 'Failed'
  | 'Manual Action Required';

export interface PreparedFormData {
  applicantName: string;
  applicantEmail: string;
  applicantPhone: string;
  currentLocation: string;
  coverLetter: string;
  relocationConfirmed: boolean;
  sponsorshipNeeded: boolean;
  keySkillsSummary: string;
  yearsOfExperience: number;
}

export interface ApplicationRecord {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  country: string;
  originalUrl: string;
  jobSource: string;
  matchScore: number;
  sponsorshipEvidence: string;
  dateDiscovered: string;
  status: ApplicationStatus;
  submissionMode: 'automatic' | 'manual';
  submissionDate?: string;
  confirmationRef?: string;
  lastStatusUpdate: string;
  notes?: string;
  nextFollowUpDate?: string;
  coverLetter?: string;
  preparedFormData?: PreparedFormData;
  failureReason?: string;
}

export interface CoverLetterRecord {
  id: string;
  jobId?: string;
  jobTitle: string;
  company: string;
  dateGenerated: string;
  content: string;
  tailoredHighlights: string[];
}

export interface RunHistoryItem {
  id: string;
  timestamp: string;
  jobsDiscovered: number;
  jobsMatched: number;
  applicationsPrepared: number;
  applicationsSubmitted: number;
  manualActionRequired: number;
  status: 'completed' | 'partial' | 'failed';
  notes: string;
}

export interface AutomationScheduleConfig {
  isActive: boolean;
  frequency: 'every_hour' | 'every_6_hours' | 'every_12_hours' | 'once_daily';
  maxApplicationsPerRun: number;
  autoSubmitEnabled: boolean;
  lastRunAt?: string;
  nextRunAt?: string;
  runHistory: RunHistoryItem[];
}

export interface SearchHistoryRecord {
  id: string;
  timestamp: string;
  query: string;
  country: string;
  source: string;
  resultsCount: number;
  matchedCount: number;
}

export interface DashboardStats {
  jobsDiscovered: number;
  jobsMatchingProfile: number;
  sponsorshipIdentified: number;
  applicationsPrepared: number;
  applicationsSubmitted: number;
  manualActionRequired: number;
  failedSubmissions: number;
  interviewInvitations: number;
  lastSuccessfulRun?: string;
  nextScheduledRun?: string;
}
