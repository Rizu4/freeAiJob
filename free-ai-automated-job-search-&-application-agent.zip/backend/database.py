"""
SQLite Database module for Free AI Job Search & Application Agent
Stores candidate profile, job preferences, discovered listings, application history, and logs.
Zero cloud costs, 100% private and persistent.
"""

import sqlite3
import json
import os
from datetime import datetime
from typing import Dict, Any, List, Optional

DB_PATH = os.environ.get("SQLITE_DB_PATH", os.path.join(os.path.dirname(__file__), "job_agent.db"))

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Candidate Profile table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS candidate_profile (
        id TEXT PRIMARY KEY,
        full_name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        current_city TEXT,
        current_country TEXT,
        work_authorization TEXT, -- JSON array
        summary TEXT,
        skills TEXT, -- JSON array
        software_tools TEXT, -- JSON array
        certifications TEXT, -- JSON array
        languages TEXT, -- JSON array
        education TEXT, -- JSON array
        experience TEXT, -- JSON array
        total_years_experience REAL,
        preferred_titles TEXT, -- JSON array
        preferred_industries TEXT, -- JSON array
        cv_raw_text TEXT,
        updated_at TEXT
    )
    """)

    # Job Preferences table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS job_preferences (
        id TEXT PRIMARY KEY,
        target_countries TEXT, -- JSON array
        target_roles TEXT, -- JSON array
        experience_levels TEXT, -- JSON array
        minimum_salary REAL,
        currency TEXT,
        willing_to_relocate BOOLEAN,
        require_visa_sponsorship BOOLEAN,
        remote_allowed BOOLEAN,
        minimum_match_score INTEGER,
        excluded_employers TEXT, -- JSON array
        enabled_sources TEXT -- JSON array
    )
    """)

    # Discovered Jobs table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        company TEXT NOT NULL,
        location TEXT,
        country TEXT NOT NULL,
        is_remote BOOLEAN,
        job_type TEXT,
        salary_text TEXT,
        description TEXT,
        original_url TEXT UNIQUE,
        source TEXT,
        date_discovered TEXT,
        has_sponsorship BOOLEAN,
        sponsorship_evidence TEXT,
        match_score INTEGER,
        match_breakdown TEXT, -- JSON object
        application_method TEXT, -- 'auto_permitted' or 'manual_required'
        manual_action_reason TEXT
    )
    """)

    # Applications table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS applications (
        id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        job_title TEXT NOT NULL,
        company TEXT NOT NULL,
        country TEXT NOT NULL,
        original_url TEXT,
        job_source TEXT,
        match_score INTEGER,
        sponsorship_evidence TEXT,
        date_discovered TEXT,
        status TEXT NOT NULL, -- 'Discovered', 'Matched', 'Prepared', 'Submitted', 'Manual Action Required', etc.
        submission_mode TEXT, -- 'automatic' or 'manual'
        submission_date TEXT,
        confirmation_ref TEXT,
        last_status_update TEXT,
        notes TEXT,
        next_follow_up_date TEXT,
        cover_letter TEXT,
        prepared_form_data TEXT, -- JSON
        failure_reason TEXT,
        FOREIGN KEY (job_id) REFERENCES jobs(id)
    )
    """)

    # Schedule & Run History table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS run_history (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        jobs_discovered INTEGER,
        jobs_matched INTEGER,
        applications_prepared INTEGER,
        applications_submitted INTEGER,
        manual_action_required INTEGER,
        status TEXT,
        notes TEXT
    )
    """)

    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("SQLite database schema initialized successfully at:", DB_PATH)
